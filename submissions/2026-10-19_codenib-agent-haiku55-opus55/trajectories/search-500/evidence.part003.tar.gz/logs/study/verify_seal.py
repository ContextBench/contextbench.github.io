"""Replay actual archived first/scout observations without inference or labels.

Use two already-exposed development tasks, never current500 Gold. The actual
freezer must reproduce their source unions, retain malformed/missing terminal
evidence, and spell out every unclaimed position without inventing observations.
"""

import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "core-search-pair-8"
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original = load(OLD / "protocol.json")
cases = [{**case, "original_inst_id": "fixture-original-" + str(i), "repo_alias_cluster": case["repo"]} for i,case in enumerate(original["cases"][:2])]
evaluator = load(ROOT.parent / "core-search-pair-independent-32/protocol.json")
results = []
for fault in ["none", "truncated_checkpoint", "unknown_fee", "missing_case_terminal", "all_unclaimed"]:
    with tempfile.TemporaryDirectory(prefix="cb500-source-replay-") as directory:
        target = Path(directory)
        for name in ["report.py", "postprocess.py", "case.py", "run.py"]:
            shutil.copyfile(ROOT / name, target / name)
        for name in ["design.json", "selection.json"]:
            (target / name).write_text("{}")
        plan = {
            "runtime": original["runtime"], "commit": original["commit"],
            "implementation": original["implementation"],
            "cases": cases, "population": 2, "worker_order": ["first", "scout"],
            "source_fingerprints": original["source_fingerprints"],
            "haiku_model": original["haiku_model"],
        }
        for name, field in [("report.py", "report_driver_sha256"), ("postprocess.py", "postprocess_driver_sha256"), ("case.py", "case_driver_sha256"), ("run.py", "driver_sha256"), ("design.json", "design_sha256"), ("selection.json", "selection_sha256")]:
            plan[field] = sha(target / name)
        dataset=target/"fixture.parquet"
        pq.write_table(pa.Table.from_pylist([{"instance_id": c["instance_id"], "gold_context": []} for c in cases]),dataset)
        baseline_rows=[]
        for i,c in enumerate(cases):
            values={"recall":.4 if i==0 else 0.0,"precision":.4 if i==0 else 0.0,"f1":.4 if i==0 else 0.0}
            baseline_rows.append({"instance_id":c["instance_id"],"official_valid":i==0,"file":values,"block":values,"line":values})
        baseline=target/"fixture-baseline.json"
        baseline.write_text(json.dumps({"population":2,"cases":baseline_rows,"failure_accounted_snapshot_macro":{level:{m:.2 for m in ["recall","precision","f1"]} for level in ["file","block","line"]},"known_baseline_Max_nominal_sdk_usd":1.0,"selected_native_unknown_usage_cases":[cases[1]["instance_id"]]}))
        plan.update(scope="Synthetic two-case accounting/official-bridge test; no real Gold",dataset=str(dataset),dataset_sha256=sha(dataset),baseline_analysis=str(baseline),baseline_analysis_sha256=sha(baseline))
        for field in ["evaluator_sources","evaluator_upstream","evaluator_python"]:plan[field]=evaluator[field]
        (target / "protocol.json").write_text(json.dumps(plan))
        (target / "live").mkdir()
        terminal = {"state": "finished", "rows": [{"instance_id": c["instance_id"], "accepted": True} for c in cases], "unclaimed_ids": [], "unknown_worker_fees": 0}
        if fault != "all_unclaimed":
            for case in cases:
                src = OLD / "live" / case["language"]
                folder = target / "live" / case["instance_id"]
                folder.mkdir()
                end = copy.deepcopy(load(src / "case-terminal.json"))
                end["workers"] = {label: end["workers"][label] for label in ["first", "scout"]}
                end["all2_accepted"] = True
                for label in ["first", "scout"]:
                    shutil.copytree(src / label, folder / label)
                    end["workers"][label]["raw"] = str(folder / label / "trajectory.json")
                shutil.copyfile(src / "haiku_scout_pair-prediction.json", folder / "haiku_scout_pair-prediction.json")
                (folder / "case-terminal.json").write_text(json.dumps(end))
            folder = target / "live" / cases[0]["instance_id"]
            rawpath = folder / "first/trajectory.json"
            if fault == "truncated_checkpoint":
                rawpath.write_text("{broken")
            if fault == "unknown_fee":
                raw = load(rawpath)
                raw["sdk_reported_cost_usd"] = None
                rawpath.write_text(json.dumps(raw))
            if fault == "missing_case_terminal":
                (folder / "case-terminal.json").unlink()
        else:
            terminal.update(state="stopped", rows=[], unclaimed_ids=[c["instance_id"] for c in cases])
        (target / "live-terminal.json").write_text(json.dumps(terminal))
        result = subprocess.run([sys.executable, str(target / "report.py"), "freeze"], capture_output=True, text=True, timeout=60)
        assert result.returncode == 0, result.stderr
        seal = load(target / "sealed-comparison.json")
        assert len(seal["receipts"]) == 2 and len(seal["worker_positions"]) == 4
        assert len({(p["instance_id"], p["worker"]) for p in seal["worker_positions"]}) == 4
        assert not (target / "annotation-access.json").exists()
        if fault == "none":
            assert all(r["accepted"] for r in seal["receipts"])
            for case, pred in zip(cases, seal["arms"]["haiku_scout_pair"], strict=True):
                assert pred == load(OLD / "live" / case["language"] / "haiku_scout_pair-prediction.json")
        elif fault == "all_unclaimed":
            assert all(not p["dispatched"] and p["fee_usd"] is None and not p["unknown_fee"] for p in seal["worker_positions"])
            assert all(not r["accepted"] and not r["raw_files_sha256"] for r in seal["receipts"])
        else:
            assert seal["receipts"][0]["accepted"] is False
            assert seal["arms"]["haiku_scout_pair"][0]["traj_data"]["pred_spans"] == {}
            evidence = seal["receipts"][0]["raw_files_sha256"]
            assert evidence[str(rawpath)] == sha(rawpath)
            if fault in ["unknown_fee", "truncated_checkpoint"]:
                assert seal["worker_positions"][0]["unknown_fee"] and seal["worker_positions"][0]["fee_usd"] is None
            else:
                assert all(p["dispatched"] and p["fee_usd"] is not None for p in seal["worker_positions"])
        if fault == "none":
            graded=subprocess.run([sys.executable,str(target/"report.py"),"evaluate"],capture_output=True,text=True,timeout=120)
            assert graded.returncode==0,graded.stderr
            analysis=load(target/"analysis.json");access=load(target/"annotation-access.json")
            assert seal["sealed_unix"]<access["opened_unix"]
            assert analysis["population"]==2 and len(analysis["candidate"]["cases"])==2 and len(analysis["actual_worker_usage"])==4
            assert analysis["baseline"]["macro"]["line"]["recall"]==.2
            assert analysis["baseline"]["unknown_fee_cases"]==[cases[1]["instance_id"]]
            assert analysis["fresh_independent_sample"] is False and analysis["official_submission_ready"] is False
        results.append({"fixture": fault, "configuration_positions_preserved": 2, "worker_positions_preserved": 4, "accepted_configurations": sum(r["accepted"] for r in seal["receipts"]), "Gold_opened": False})
receipt = {"actual_report_driver_sha256": sha(ROOT / "report.py"), "cached_source_population": "same two already-exposed development tasks only", "fixtures": results, "actual_union_replay_verified": fault is not None, "official_bridge_synthetic_evaluation_passed": True, "baseline_failed_zero_and_unknown_fee_preserved": True, "new_model_calls": 0, "new_real_annotation_reads": 0, "synthetic_Gold_reads": 2}
with (ROOT / "seal-verification.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt))
