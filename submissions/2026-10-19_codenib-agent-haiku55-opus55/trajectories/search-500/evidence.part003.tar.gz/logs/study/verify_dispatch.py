"""Execute actual dispatch bytes against local fake workers, with no credentials.

Check eight-case windows, no second window after unknown fees/failures, and the
reservation gate before any intent. Fake dotenv returns a literal test token;
no secret file, SDK or provider is imported by any fixture child.
"""

import ast
import hashlib
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
driver = (ROOT / "run.py").read_bytes()
case_bytes = (ROOT / "case.py").read_bytes()
case_tree = ast.parse(case_bytes)
execute = next(n for n in case_tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "execute")
calls = [n for n in ast.walk(execute) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "run_worker"]
assert [n.args[0].value for n in calls] == ["first", "scout"]
assert not any(isinstance(n, (ast.For, ast.AsyncFor)) for n in ast.walk(execute))
retrieve = next(n for n in ast.walk(case_tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "retrieve")
assert next(k.value.value for k in retrieve.keywords if k.arg == "max_turns") == 20
fixture_rows = []

FAKE_CASE = '''import json,sys
from pathlib import Path
r=Path(__file__).resolve().parent;key=sys.argv[1];fault=json.loads((r/'fault.json').read_text());folder=r/'live'/key;folder.mkdir()
workers={}
for label in ['first','scout']:
 p=folder/label;p.mkdir();fee=None if fault=='unknown_fee' and key=='case-00' and label=='first' else .01
 (p/'model-intent.json').write_text('{}');(p/'trajectory.json').write_text('{broken' if fault=='truncated_checkpoint' and key=='case-00' and label=='first' else json.dumps({'sdk_reported_cost_usd':fee}))
 workers[label]={'label':label}
ok=not(key=='case-00' and fault in ['unknown_fee','unaccepted'])
(folder/'case-terminal.json').write_text(json.dumps({'workers':workers,'all2_accepted':ok}))
'''

for fault in ["none", "budget", "unknown_fee", "unaccepted", "unreserved", "truncated_checkpoint", "missing_readiness"]:
    with tempfile.TemporaryDirectory(prefix="cb500-dispatch-fixture-") as directory:
        target = Path(directory)
        (target / "run.py").write_bytes(driver)
        (target / "case.py").write_text(FAKE_CASE)
        (target / "fault.json").write_text(json.dumps(fault))
        (target / "dotenv.py").write_text("def dotenv_values(*args,**kwargs): return {'ANTHROPIC_API_KEY':'fixture-only-no-network'}\n")
        cap = 1.96 if fault == "budget" else 12
        plan = {
            "runtime": "/tmp/codenib-contextbench-search-pair-runtime",
            "commit": "71e489e5875ca19d73bd15c417b339fb43225439",
            "implementation": {}, "case_concurrency": 8,
            "driver_sha256": hashlib.sha256(driver).hexdigest(),
            "case_driver_sha256": hashlib.sha256((target / "case.py").read_bytes()).hexdigest(),
            "python": sys.executable, "haiku_model": "fixture-haiku",
            "maximum_observed_worker_usd": {"fixture-haiku": .12},
            "API_batch_guard_usd": cap,
            "cases": [{"instance_id": f"case-{i:02d}", "language": "python"} for i in range(16)],
        }
        (target / "protocol.json").write_text(json.dumps(plan))
        (target / "budget-reservation.json").write_text(json.dumps({
            "state": "unreserved" if fault == "unreserved" else "reserved",
            "reservation_usd": cap, "known_program_API_usage_usd_before": 75.330733235,
            "protocol_sha256": hashlib.sha256((target / "protocol.json").read_bytes()).hexdigest(),
        }))
        if fault != "missing_readiness":
            (target / "execution-readiness.json").write_text(json.dumps({"protocol_sha256": hashlib.sha256((target / "protocol.json").read_bytes()).hexdigest(), "all500_sources_ready": True, "budget_views_reconciled": True}))
        result = subprocess.run([sys.executable, str(target / "run.py")], capture_output=True, text=True, timeout=30)
        if fault in {"unreserved", "missing_readiness"}:
            assert result.returncode != 0 and not (target / "live-intent.json").exists()
            fixture_rows.append({"fixture": fault, "rejected_before_intent_or_worker": True})
            continue
        terminal = json.loads((target / "live-terminal.json").read_text())
        expected = 16 if fault == "none" else 8
        assert len(terminal["rows"]) == expected
        assert len(terminal["unclaimed_ids"]) == 16 - expected
        assert len(list((target / "live").glob("*/case-terminal.json"))) == expected
        assert len(list((target / "live").glob("*/*/model-intent.json"))) == expected * 2
        assert terminal["unknown_worker_fees"] == (1 if fault in {"unknown_fee", "truncated_checkpoint"} else 0)
        assert terminal["state"] == ("finished" if fault == "none" else "stopped")
        expected_fee = expected * .02 - (.01 if fault in {"unknown_fee", "truncated_checkpoint"} else 0)
        assert math.isclose(terminal["known_new_API_usage_usd"], expected_fee, abs_tol=1e-12)
        assert result.returncode == (0 if fault == "none" else 1)
        if fault == "truncated_checkpoint":
            assert terminal["rows"][0]["terminal_parse_errors"] and (target/"live/case-00/first/trajectory.json").read_text() == "{broken"
        fixture_rows.append({
            "fixture": fault, "dispatched_cases": expected,
            "dispatched_worker_intents": expected * 2,
            "unclaimed_cases_preserved": 16 - expected,
            "unknown_fees": terminal["unknown_worker_fees"],
            "known_usage_usd": terminal["known_new_API_usage_usd"],
        })

receipt = {
    "actual_dispatch_driver_sha256": hashlib.sha256(driver).hexdigest(),
    "case_driver_sha256": hashlib.sha256(case_bytes).hexdigest(),
    "unchanged_two_worker_order": ["first", "scout"],
    "same20turn_retrieve_call_verified": True,
    "fixtures": fixture_rows, "real_credentials_read": False,
    "real_source_or_issue_or_Gold_read": False, "new_model_calls": 0,
}
with (ROOT / "dispatch-verification.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt))
