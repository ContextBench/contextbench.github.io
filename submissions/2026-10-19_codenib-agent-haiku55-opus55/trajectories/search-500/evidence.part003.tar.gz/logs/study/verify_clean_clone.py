"""Verify a fresh pinned public checkout preserves the recorded source identity.

Use one already-exposed development repository. Follow the exact original
declared-submodule/unmapped-gitlink contract; never initialize invented sources.
Git fetches public source, but no provider model, issue or Gold request is made.
"""

import hashlib
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "core-search-pair-8"
load = lambda path: json.loads(path.read_text())
plan = load(OLD / "protocol.json")
sys.path.insert(0, plan["runtime"])
from codenib.dataset.contextbench import ContextBenchCase
from codenib.eval.benchmarks.contextbench_runner import audit_contextbench_snapshot, prepare_contextbench_repo
from codenib.source_fingerprint import fingerprint_repository

metadata = plan["cases"][0]
case = ContextBenchCase(instance_id=metadata["instance_id"], original_inst_id="source-only-reproduction-check", repo=metadata["repo"], repo_url=metadata["repo_url"], base_commit=metadata["base_commit"], language=metadata["language"], source="", problem_statement="", gold_context=())
with tempfile.TemporaryDirectory(prefix="fixture-cb500-clean-source-", dir=ROOT.parent) as directory:
    repo = prepare_contextbench_repo(case, Path(directory))
    snapshot = audit_contextbench_snapshot(repo, case.base_commit)
    actual = fingerprint_repository(repo)
    expected = plan["source_fingerprints"][case.instance_id]
    assert actual.value == expected
    result = {"instance_id": case.instance_id, "repo_url": case.repo_url, "base_commit": case.base_commit, "source_fingerprint": actual.value, "file_count": actual.file_count, "fresh_checkout_matches_recorded_full_source_identity": True, "snapshot_clean": snapshot["clean"], "unavailable_gitlinks": snapshot.get("unavailable_gitlinks", []), "new_model_calls": 0, "new_issue_or_Gold_reads": 0, "actual_cached_source_modified": False, "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (ROOT / "clean-source-reproduction-verification.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
