"""Synthetic500 export/accounting tests; never write actual public assets."""

import csv
import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location("fixture_publisher", ROOT / "publish.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
results = []
for fault in ["none", "reservation_not_closed", "ledger_not_reconciled"]:
    with tempfile.TemporaryDirectory(prefix="cb500-public-export-") as directory:
        base = Path(directory)
        study, native, output = base / "study", base / "baseline", base / "exports"
        study.mkdir()
        native.mkdir()

        def save(folder, name, data):
            (folder / name).write_text(json.dumps(data))

        cases, candidate, controls, receipts, predictions, usage = [], [], [], [], [], []
        cmetrics = {level: {"recall": .6, "precision": .5, "f1": 2 * .6 * .5 / 1.1} for level in module.LEVELS}
        bmetrics = {"recall": .4, "precision": .5, "f1": 2 * .4 * .5 / .9}
        for i in range(500):
            key = f"fixture-{i:03d}"
            cases.append({"instance_id": key, "language": "python", "repo": "fixture/repo", "base_commit": "0" * 40, "repo_alias_cluster": "fixture-cluster"})
            candidate.append({"instance_id": key, "valid": True, "metrics": cmetrics, "assembly": {"all_model_usage_usd": .01, "unique_observed_source_lines": 6, "summed_worker_unique_source_lines": 8, "repeated_source_lines_across_workers": 2}})
            controls.append({"instance_id": key, "official_valid": i != 0, **{level: bmetrics if i else {m: 0 for m in module.METRICS} for level in ["file", "block", "line"]}})
            receipts.append({"instance_id": key, "original_failed_zero_source": i == 0, "nominal_Max_sdk_usd": .1 if i else None})
            predictions.append({"instance_id": key, "traj_data": {"pred_spans": {"f.py": [{"start": 1, "end": 4}]} if i else {}}})
            usage.extend({"instance_id": key, "worker": label, "fee_usd": .005, "SDK_loop_seconds": .1, "main_input_status": "incomplete"} for label in ["first", "scout"])
        save(native, "confirmed-native-predictions.json", {"predictions": predictions})
        save(native, "protocol.json", {"receipts": receipts, "predictions_sha256": sha(native / "confirmed-native-predictions.json")})
        save(native, "analysis.json", {"cases": controls})
        plan = {"scope": "Synthetic500 public-export test, no real inference/results", "population": 500, "cases": cases, "commit": "fixture", "baseline_analysis": str(native / "analysis.json"), "baseline_analysis_sha256": sha(native / "analysis.json"), "baseline_protocol_sha256": sha(native / "protocol.json")}
        save(study, "protocol.json", plan)
        save(study, "sealed-comparison.json", {"sealed_unix": 1, "worker_positions": [{"accepted": True, "unknown_fee": False}] * 1000})
        save(study, "annotation-access.json", {"opened_unix": 2})
        macro = {level: dict(values) for level, values in cmetrics.items()}
        old_macro = {level: {metric: bmetrics[metric] * 499 / 500 for metric in module.METRICS} for level in module.LEVELS}
        analysis = {"population": 500, "protocol_sha256": sha(study / "protocol.json"), "source_seal_sha256": sha(study / "sealed-comparison.json"), "candidate": {"cases": candidate, "macro": macro, "valid": 500}, "baseline": {"macro": old_macro, "known_Max_nominal_fee_sum_usd": 49.9, "unknown_fee_cases": [cases[0]["instance_id"]]}, "actual_worker_usage": usage, "unknown_worker_fees": 0, "known_new_API_usage_decimal": "5.000", "paired_differences_vs_frozen_native500": {}, "bootstrap": {}}
        save(study, "analysis.json", analysis)
        save(study, "postprocess-terminal.json", {"state": "finished", "analysis_sha256": sha(study / "analysis.json")})
        save(study, "budget-reservation-closure.json", {"state": "reserved" if fault == "reservation_not_closed" else "closed", "new_known_API_usage_decimal": "5.000", "known_program_API_usage_usd": 80.330733235, "remaining_API_allowance_usd": 19.669266765})
        save(study, "budget-settlement-verification.json", {"both_existing_state_views_reconciled": fault != "ledger_not_reconciled", "closure_sha256": sha(study / "budget-reservation-closure.json")})
        if fault == "none":
            result = module.export(study, output)
            assert result["public_rows"] == 1000
            rows = list(csv.DictReader((output / "contextbench_search_pair_verified_500.csv").open()))
            failed = next(r for r in rows if r["arm"] == "frozen_opus_native" and r["instance_id"] == "fixture-000")
            assert failed["line_recall"] == "0" and failed["nominal_fee_usd"] == "" and failed["fee_known"] == "False" and failed["execution_valid"] == "False"
            summary = json.loads((output / "contextbench_search_pair_verified_summary.json").read_text())
            assert not summary["baseline_fees_complete"] and summary["baseline_original_failed_zero_positions"] == 1
            assert not summary["official_submission_ready"] and not summary["fresh_independent_sample"]
        else:
            try:
                module.export(study, output)
            except AssertionError:
                pass
            else:
                raise AssertionError("Incomplete fee settlement must block publication")
            assert not output.exists()
        results.append({"fixture": fault, "synthetic_public_rows_verified": 1000 if fault == "none" else 0, "unknown_baseline_fee_and_failed_zero_preserved": fault == "none", "blocked_before_output": fault != "none"})
receipt = {"actual_publish_driver_sha256": sha(ROOT / "publish.py"), "fixtures": results, "actual_public_assets_modified": False, "new_model_calls": 0, "real_issues_Gold_source_or_provider_IDs_read": False}
with (ROOT / "public-export-fixture-verification.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt))
