"""Verify incomplete preparation never creates issues, protocol or reservation."""

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
data = (ROOT / "freeze.py").read_bytes()
rows = []
for fault in ["missing_source_terminal", "incomplete_499", "preparation_opened_labels"]:
    with tempfile.TemporaryDirectory(prefix="cb500-freeze-gate-") as directory:
        target = Path(directory)
        (target / "freeze.py").write_bytes(data)
        (target / "design.json").write_text("{}")
        (target / "selection.json").write_text("{}")
        if fault != "missing_source_terminal":
            (target / "preparation-terminal.json").write_text(json.dumps({"all_ready": fault != "incomplete_499", "selected": 500, "ready": 499 if fault == "incomplete_499" else 500, "issue_or_Gold_columns_read": fault == "preparation_opened_labels", "API_calls": 0}))
        result = subprocess.run([sys.executable, str(target / "freeze.py")], capture_output=True, text=True, timeout=30)
        assert result.returncode != 0 and ("FileNotFoundError" if fault == "missing_source_terminal" else "AssertionError") in result.stderr
        assert all(not (target / name).exists() for name in ["issue-access.json", "inputs", "protocol.json", "budget-reservation.json", "execution-readiness.json"])
        rows.append({"fixture": fault, "rejected_before_issues_inputs_protocol_or_reservation": True})
out = {"freeze_driver_sha256": hashlib.sha256(data).hexdigest(), "fixtures": rows, "new_model_calls": 0, "new_annotation_reads": 0, "actual_budget_state_mutated": False}
with (ROOT / "freeze-preparation-gate-verification.json").open("x") as stream:
    json.dump(out, stream, indent=2)
    stream.write("\n")
print(json.dumps(out))
