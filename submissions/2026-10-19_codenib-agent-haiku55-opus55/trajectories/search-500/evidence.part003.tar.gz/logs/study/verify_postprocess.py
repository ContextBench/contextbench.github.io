"""Exercise actual source-to-Gold ordering with synthetic local two-case data."""

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
driver = (ROOT / "postprocess.py").read_bytes()
rows = []
for fault in ["none", "unaccepted", "unknown_fee", "duplicate_config", "duplicate_worker", "unclaimed_worker", "missing_raw", "unknown_position_fee", "protocol_integrity"]:
    with tempfile.TemporaryDirectory(prefix="cb500-source-order-") as directory:
        target = Path(directory)
        (target / "postprocess.py").write_bytes(driver)
        plan = {"cases": [{"instance_id": "a"}, {"instance_id": "b"}], "worker_order": ["first", "scout"], "postprocess_driver_sha256": hashlib.sha256(driver).hexdigest()}
        terminal = {"state": "finished", "rows": [{"instance_id": "a", "accepted": fault != "unaccepted"}, {"instance_id": "b", "accepted": True}], "unknown_worker_fees": 1 if fault == "unknown_fee" else 0, "unclaimed_ids": []}
        for name, data in [("protocol.json", plan), ("live-terminal.json", terminal), ("fault.json", fault)]:
            (target / name).write_text(json.dumps(data))
        owner = subprocess.Popen([sys.executable, "-c", "pass"])
        owner.wait()
        (target / "live-intent.json").write_text(json.dumps({"pid": owner.pid}))
        (target / "report.py").write_text('''import json,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent
if sys.argv[1]=='freeze':
 p=json.loads((r/'protocol.json').read_text());fault=json.loads((r/'fault.json').read_text())
 receipts=[{'instance_id':c['instance_id'],'arm':'haiku_scout_pair','accepted':True,'integrity_errors':[]} for c in p['cases']]
 workers=[{'instance_id':c['instance_id'],'worker':w,'accepted':True,'dispatched':True,'unknown_fee':False,'fee_usd':.01,'raw_sha256':'fixture'} for c in p['cases'] for w in p['worker_order']]
 if fault=='duplicate_config':receipts[-1]=receipts[0]
 if fault=='duplicate_worker':workers[-1]=workers[0]
 if fault=='unclaimed_worker':workers[-1]['dispatched']=False
 if fault=='missing_raw':workers[-1]['raw_sha256']=None
 if fault=='unknown_position_fee':workers[-1]['fee_usd']=None
 (r/'sealed-comparison.json').write_text(json.dumps({'receipts':receipts,'worker_positions':workers,'new_annotation_reads_at_freeze':0,'protocol_integrity_errors':['fixture'] if fault=='protocol_integrity' else [],'sealed_unix':time.time()}))
else:
 assert (r/'sealed-comparison.json').exists()
 (r/'annotation-access.json').write_text(json.dumps({'opened_unix':time.time()}));(r/'analysis.json').write_text('{}')
''')
        result = subprocess.run([sys.executable, str(target / "postprocess.py")], capture_output=True, text=True, timeout=30)
        assert (target / "sealed-comparison.json").exists(), result.stderr
        opened = (target / "annotation-access.json").exists()
        assert opened == (fault == "none"), result.stderr
        assert result.returncode == (0 if fault == "none" else 2), result.stderr
        if opened:
            sealed = json.loads((target / "sealed-comparison.json").read_text())
            access = json.loads((target / "annotation-access.json").read_text())
            assert sealed["sealed_unix"] < access["opened_unix"]
        rows.append({"fixture": fault, "source_outcomes_sealed": True, "Gold_projection_reached": opened, "exit_code": result.returncode})
out = {"driver_sha256": hashlib.sha256(driver).hexdigest(), "fixtures": rows, "new_model_calls": 0, "new_annotation_reads": 0, "real_source_and_credentials_read": False}
with (ROOT / "postprocess-order-verification.json").open("x") as stream:
    json.dump(out, stream, indent=2)
    stream.write("\n")
print(json.dumps(out))
