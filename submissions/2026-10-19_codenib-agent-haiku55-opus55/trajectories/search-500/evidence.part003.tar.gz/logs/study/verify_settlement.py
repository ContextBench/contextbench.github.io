"""Financial recovery fixtures with synthetic fees and two temporary ledgers.

No actual500 worker, original ledger, source, label or provider is touched.
The same actual settlement functions process a synthetic1,000-position batch.
"""

import copy
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, value: p.write_text(json.dumps(value, indent=2) + "\n")
spec = importlib.util.spec_from_file_location("fixture_settle", ROOT / "settle_budget.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
results = []


def views(root, protocol_sha, before):
    paths = [root / "fixture-ledger-one.json", root / "fixture-ledger-two.json"]
    for index, path in enumerate(paths):
        state = {"unrelated_marker": "preserve-me", "active_API_reservation_usd": 12, "remaining_API_allowance_usd": float(100 - before), "remaining_unreserved_API_allowance_usd": float(88 - before), "search_pair_verified500": {"new_usage_accounted": False, "protocol_sha256": protocol_sha, "active_API_reservation_usd": 12}}
        if index == 0:
            state["known_program_api_usage_value_usd"] = float(before)
        else:
            state.update(program_known_API_usage_value_usd=float(before), current_known_program_API_usage_value_usd=float(before))
        write(path, state)
    return paths


def refresh(root):
    analysis = load(root / "analysis.json")
    analysis["source_seal_sha256"] = sha(root / "sealed-comparison.json")
    write(root / "analysis.json", analysis)
    post = load(root / "postprocess-terminal.json")
    post["analysis_sha256"] = sha(root / "analysis.json")
    write(root / "postprocess-terminal.json", post)


def rejected(root, paths, label):
    before = [p.read_bytes() for p in paths]
    closure = root / "budget-reservation-closure.json"
    previous = closure.read_bytes() if closure.exists() else None
    try:
        module.reconcile(root, paths)
    except AssertionError:
        pass
    else:
        raise AssertionError("Accepted invalid settlement fixture: " + label)
    assert before == [p.read_bytes() for p in paths]
    assert (closure.read_bytes() if closure.exists() else None) == previous
    results.append({"fixture": label, "rejected_before_ledger_mutation": True})


with tempfile.TemporaryDirectory(prefix="fixture-cb500-settlement-", dir=ROOT.parent) as directory:
    base = Path(directory)
    prior_dir = base / "core-search-pair-independent-32"
    prior_dir.mkdir()
    shutil.copyfile(ROOT.parent / "core-search-pair-independent-32/budget-reservation-closure.json", prior_dir / "budget-reservation-closure.json")
    before = Decimal(load(prior_dir / "budget-reservation-closure.json")["known_program_API_usage_decimal"])
    original = base / "original"
    original.mkdir()
    ids = [f"fixture-case-{i:04d}" for i in range(500)]
    plan = {"cases": [{"instance_id": key} for key in ids], "population": 500, "worker_order": ["first", "scout"], "program_known_API_usage_before_usd": float(before), "API_batch_guard_usd": 12, "API_ceiling_usd": 100}
    write(original / "protocol.json", plan)
    protocol_sha = sha(original / "protocol.json")
    usage, positions = [], []
    for key in ids:
        for label in plan["worker_order"]:
            folder = original / "live" / key / label
            folder.mkdir(parents=True)
            path = folder / "trajectory.json"
            write(path, {"sdk_reported_cost_usd": 0.001, "sdk_result": {"model_usage": {"fixture-model": {"costUSD": 0.001}}}})
            usage.append({"instance_id": key, "worker": label, "fee_usd": 0.001})
            positions.append({"instance_id": key, "worker": label, "fee_usd": 0.001, "dispatched": True, "accepted": True, "unknown_fee": False, "raw_sha256": sha(path)})
    write(original / "sealed-comparison.json", {"worker_positions": positions})
    write(original / "analysis.json", {"population": 500, "protocol_sha256": protocol_sha, "source_seal_sha256": sha(original / "sealed-comparison.json"), "actual_worker_usage": usage, "known_new_API_usage_decimal": "1.000", "unknown_worker_fees": 0})
    write(original / "postprocess-terminal.json", {"state": "finished", "analysis_sha256": sha(original / "analysis.json")})
    write(original / "pipeline-terminal.json", {"state": "finished_source_scored"})
    write(original / "pipeline-intent.json", {"pid": os.getpid(), "source_pid": os.getpid()})
    write(original / "live-intent.json", {"pid": os.getpid()})
    write(original / "postprocess-intent.json", {"consumer_pid": os.getpid()})
    write(original / "budget-reservation.json", {"state": "reserved", "reservation_usd": 12, "protocol_sha256": protocol_sha, "known_program_API_usage_usd_before": float(before)})

    normal = base / "normal"
    shutil.copytree(original, normal)
    paths = views(normal, protocol_sha, before)
    original_second = paths[1].read_bytes()
    owner = subprocess.Popen([sys.executable, "-c", "import sys;sys.stdin.read()", str(normal / "finish_pipeline.py")], stdin=subprocess.PIPE)
    write(normal / "pipeline-intent.json", {"pid": owner.pid, "source_pid": os.getpid()})
    try:
        rejected(normal, paths, "active_original_owner")
    finally:
        owner.terminate()
        owner.wait(timeout=5)
    proof = module.reconcile(normal, paths)
    assert Decimal(proof["program_API_usage_decimal"]) == before + 1
    assert proof["distinct_actual_sessions"] == 1000
    assert all(load(p)["unrelated_marker"] == "preserve-me" for p in paths)
    results.append({"fixture": "actual_distinct_fees_added_once", "synthetic_delta_decimal": "1.000"})
    saved = [p.read_bytes() for p in paths]
    assert module.reconcile(normal, paths) == proof and saved == [p.read_bytes() for p in paths]
    results.append({"fixture": "already_reconciled_repeat", "ledger_bytes_unchanged": True})
    paths[1].write_bytes(original_second)
    (normal / "budget-settlement-verification.json").unlink()
    assert module.reconcile(normal, paths) == proof
    assert saved == [p.read_bytes() for p in paths]
    results.append({"fixture": "recover_after_first_ledger_commit", "same_fixed_delta_not_added_again": True})
    corrupted = load(paths[1])
    corrupted["program_known_API_usage_value_usd"] += 0.5
    write(paths[1], corrupted)
    rejected(normal, paths, "unexpected_existing_ledger_value")

    for fault in ["unknown_fee", "duplicate_usage", "changed_original_receipt", "pipeline_stopped"]:
        target = base / fault
        shutil.copytree(original, target)
        paths = views(target, protocol_sha, before)
        if fault == "unknown_fee":
            analysis = load(target / "analysis.json")
            analysis["unknown_worker_fees"] = 1
            write(target / "analysis.json", analysis)
            refresh(target)
        elif fault == "duplicate_usage":
            analysis = load(target / "analysis.json")
            analysis["actual_worker_usage"][0] = copy.deepcopy(analysis["actual_worker_usage"][1])
            write(target / "analysis.json", analysis)
            refresh(target)
        elif fault == "changed_original_receipt":
            path = target / "live" / ids[0] / "first/trajectory.json"
            write(path, {"sdk_reported_cost_usd": 999})
        else:
            write(target / "pipeline-terminal.json", {"state": "stopped"})
        rejected(target, paths, fault)

    overrun = base / "overrun"
    shutil.copytree(original, overrun)
    analysis = load(overrun / "analysis.json")
    seal = load(overrun / "sealed-comparison.json")
    for row in analysis["actual_worker_usage"]:
        row["fee_usd"] = 0.03
    for row in seal["worker_positions"]:
        row["fee_usd"] = 0.03
        path = overrun / "live" / row["instance_id"] / row["worker"] / "trajectory.json"
        write(path, {"sdk_reported_cost_usd": 0.03, "sdk_result": {"model_usage": {"fixture-model": {"costUSD": 0.03}}}})
        row["raw_sha256"] = sha(path)
    analysis["known_new_API_usage_decimal"] = "30.000"
    write(overrun / "analysis.json", analysis)
    write(overrun / "sealed-comparison.json", seal)
    refresh(overrun)
    paths = views(overrun, protocol_sha, before)
    module.reconcile(overrun, paths)
    closure = load(overrun / "budget-reservation-closure.json")
    assert closure["program_API_ceiling_exceeded"] and closure["remaining_API_allowance_usd"] < 0
    assert Decimal(closure["known_program_API_usage_decimal"]) == before + 30
    assert Decimal(closure["reservation_overrun_decimal"]) == 18
    results.append({"fixture": "known_overrun_remains_actual_spend", "overrun_exposed_not_dropped": True})

proof = {"actual_settlement_driver_sha256": sha(ROOT / "settle_budget.py"), "fixtures": results, "synthetic_worker_positions_per_fixture": 1000, "actual_SDK_sessions": 0, "actual_program_ledgers_modified": False, "new_model_calls": 0, "new_annotation_reads": 0}
with (ROOT / "settlement-fixture-verification.json").open("x") as output:
    json.dump(proof, output, indent=2)
    output.write("\n")
print(json.dumps(proof))
