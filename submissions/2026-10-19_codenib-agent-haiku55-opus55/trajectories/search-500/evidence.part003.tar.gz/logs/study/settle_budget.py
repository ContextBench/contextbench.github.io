"""Settle this completed fixed500 batch once; never issue provider requests.

Root is the sole accounting/recovery owner. No new paid batch may start until
both existing budget views reconcile. Original execution owners must be dead.
An immutable closure fixes the actual distinct-session delta before ledger
updates. Each ledger replacement atomically includes its new cumulative value
and closure marker: that replacement is its linearization point. After an
interruption, root reuses this exact closure and replaces only the remaining
old views, never adds a delta to an already-updated value. Unexpected ledger
values, unknown fees and changed source receipts stop without estimating them.
This is usage-value accounting, not an invoice/credit reconciliation.
"""

import hashlib
import json
import math
import os
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/researcher/SysEvol/CodeMiner")
STATE_PATHS = [
    REPO / "verification/contextbench-first-source-24-20261016/work-status.json",
    REPO / "verification/contextbench-native-interim-20261017/on-demand-core-context-plan.json",
]
USAGE_FIELDS = [
    "known_program_api_usage_value_usd",
    "program_known_API_usage_value_usd",
    "current_known_program_API_usage_value_usd",
]
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def save_new(path, value):
    with path.open("x") as output:
        json.dump(value, output, indent=2, ensure_ascii=False, allow_nan=False)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())


def replace_state(path, value):
    target = path.resolve(strict=True)
    temporary = target.with_name(target.name + f".accounting-{os.getpid()}-tmp")
    with temporary.open("x") as output:
        json.dump(value, output, indent=2, ensure_ascii=False, allow_nan=False)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, target)


def same(value, expected):
    return type(value) in (int, float) and math.isfinite(value) and math.isclose(value, float(expected), rel_tol=0, abs_tol=1e-10)


def original_owners_dead(root):
    intent = load(root / "pipeline-intent.json")
    for pid, script in [(intent["pid"], "finish_pipeline.py"), (intent["source_pid"], "prepare.py")]:
        command = Path("/proc") / str(pid) / "cmdline"
        assert not command.exists() or str(root / script).encode() not in command.read_bytes().split(b"\0"), "Original pipeline/source owner is still live"
    for name, script in [("live-intent.json", "run.py"), ("postprocess-intent.json", "postprocess.py")]:
        owner = load(root / name)
        pid = owner["pid"] if "pid" in owner else owner["consumer_pid"]
        command = Path("/proc") / str(pid) / "cmdline"
        assert not command.exists() or str(root / script).encode() not in command.read_bytes().split(b"\0"), "Original model/scoring owner is still live"


def completed_closure(root):
    original_owners_dead(root)
    assert load(root / "pipeline-terminal.json")["state"] == "finished_source_scored"
    post = load(root / "postprocess-terminal.json")
    assert post["state"] == "finished" and post["analysis_sha256"] == sha(root / "analysis.json")
    plan = load(root / "protocol.json")
    analysis = load(root / "analysis.json")
    seal = load(root / "sealed-comparison.json")
    reservation = load(root / "budget-reservation.json")
    assert analysis["protocol_sha256"] == reservation["protocol_sha256"] == sha(root / "protocol.json")
    assert analysis["source_seal_sha256"] == sha(root / "sealed-comparison.json")
    assert reservation["state"] == "reserved"
    assert plan["population"] == analysis["population"] == len(plan["cases"]) == 500
    ids = [case["instance_id"] for case in plan["cases"]]
    assert len(set(ids)) == 500 and plan["worker_order"] == ["first", "scout"]
    expected = {(key, worker) for key in ids for worker in plan["worker_order"]}
    usage = {(row["instance_id"], row["worker"]): row for row in analysis["actual_worker_usage"]}
    positions = {(row["instance_id"], row["worker"]): row for row in seal["worker_positions"]}
    assert len(usage) == len(analysis["actual_worker_usage"]) == 1000 and set(usage) == expected
    assert len(positions) == len(seal["worker_positions"]) == 1000 and set(positions) == expected
    assert analysis["unknown_worker_fees"] == 0
    actual = Decimal(0)
    for key, worker in sorted(expected):
        position = positions[key, worker]
        assert position["dispatched"] and position["accepted"] and not position["unknown_fee"]
        rawpath = root / "live" / key / worker / "trajectory.json"
        assert sha(rawpath) == position["raw_sha256"]
        raw = load(rawpath)
        fee = raw["sdk_reported_cost_usd"]
        assert type(fee) in (int, float) and math.isfinite(fee) and fee >= 0
        assert fee == usage[key, worker]["fee_usd"] == position["fee_usd"]
        assert math.isclose(sum(value["costUSD"] for value in raw["sdk_result"]["model_usage"].values()), fee, abs_tol=1e-10)
        actual += Decimal(str(fee))
    assert actual == Decimal(analysis["known_new_API_usage_decimal"])
    before = Decimal(load(root.parent / "core-search-pair-independent-32/budget-reservation-closure.json")["known_program_API_usage_decimal"])
    assert same(plan["program_known_API_usage_before_usd"], before)
    assert same(reservation["known_program_API_usage_usd_before"], before)
    reserved = Decimal(str(reservation["reservation_usd"]))
    assert reserved == Decimal(str(plan["API_batch_guard_usd"])) == 12
    after = before + actual
    return {
        "state": "closed", "reservation_usd": 12,
        "new_known_API_usage_decimal": str(actual),
        "known_program_API_usage_before_decimal": str(before),
        "known_program_API_usage_decimal": str(after),
        "known_program_API_usage_usd": float(after),
        "unused_reservation_released_decimal": str(max(Decimal(0), reserved - actual)),
        "reservation_overrun_decimal": str(max(Decimal(0), actual - reserved)),
        "program_API_ceiling_exceeded": after > 100,
        "remaining_API_allowance_usd": float(Decimal(100) - after),
        "active_API_reservation_usd": 0, "unknown_worker_fees": 0,
        "actual_sessions_counted_once": 1000,
        "analysis_sha256": sha(root / "analysis.json"),
        "protocol_sha256": sha(root / "protocol.json"),
        "source_seal_sha256": sha(root / "sealed-comparison.json"),
        "actual_cash_or_credit_balance_reconciled": False,
        "accounting_owner": "root; no new paid dispatch until both existing state views reconcile to this immutable closure",
        "accounting_invariant": "Distinct actual SDK fees are added once. Each atomic ledger replacement includes the cumulative value and closure marker. Recovery reuses this exact closure without adding the fee again. Known overruns remain actual spend, never silently dropped.",
    }


def eligible_state(state, closure, closure_digest):
    batch = state["search_pair_verified500"]
    fields = [name for name in USAGE_FIELDS if name in state]
    assert fields
    if batch["new_usage_accounted"]:
        assert closure_digest and batch["budget_closure_sha256"] == closure_digest
        assert batch["protocol_sha256"] == closure["protocol_sha256"]
        assert state["active_API_reservation_usd"] == batch["active_API_reservation_usd"] == 0
        assert all(same(state[name], closure["known_program_API_usage_usd"]) for name in fields)
    else:
        assert batch["protocol_sha256"] == closure["protocol_sha256"]
        assert state["active_API_reservation_usd"] == batch["active_API_reservation_usd"] == 12
        assert all(same(state[name], Decimal(closure["known_program_API_usage_before_decimal"])) for name in fields)


def reconcile(root, paths):
    assert len(paths) == 2 and len({path.resolve() for path in paths}) == 2
    expected = completed_closure(root)
    closure_path = root / "budget-reservation-closure.json"
    if closure_path.exists():
        closure = load(closure_path)
        assert closure == expected, "Existing immutable closure differs; inspect original evidence"
        digest = sha(closure_path)
    else:
        closure, digest = expected, None
    states = [load(path) for path in paths]
    for state in states:
        eligible_state(state, closure, digest)
    if digest is None:
        save_new(closure_path, closure)
        digest = sha(closure_path)
    for path in paths:
        state = load(path)
        eligible_state(state, closure, digest)
        if not state["search_pair_verified500"]["new_usage_accounted"]:
            for name in USAGE_FIELDS:
                if name in state:
                    state[name] = closure["known_program_API_usage_usd"]
            for name in ["remaining_API_allowance_usd", "remaining_unreserved_API_allowance_usd"]:
                state[name] = closure["remaining_API_allowance_usd"]
            state["active_API_reservation_usd"] = 0
            state["search_pair_verified500"].update(
                state="finished_context_scored_fee_accounted", new_usage_accounted=True,
                budget_closure_sha256=digest, active_API_reservation_usd=0,
                known_new_API_usage_decimal=closure["new_known_API_usage_decimal"],
                actual_sessions_counted_once=1000, known500_Gold_reopened=True,
                last_source_ready=500, last_source_errors=0,
            )
            state["current_next_action"] = "Export fixed500 metrics, archive exact original attempts and run complete offline source/metric reproduction. Retain original native500 failure, unknown fee and annotation timing. No new repairs or official Pass@1 claim; goal ACTIVE."
            replace_state(path, state)
        eligible_state(load(path), closure, digest)
    proof = {"closure_sha256": digest, "both_existing_state_views_reconciled": True, "distinct_actual_sessions": 1000, "all1000_worker_labels_unique_and_fees_known": True, "program_API_usage_decimal": closure["known_program_API_usage_decimal"], "remaining_API_allowance_usd": closure["remaining_API_allowance_usd"], "new_model_calls_by_settlement": 0}
    proof_path = root / "budget-settlement-verification.json"
    if proof_path.exists():
        assert load(proof_path) == proof
    else:
        save_new(proof_path, proof)
    return proof


if __name__ == "__main__":
    print(json.dumps(reconcile(ROOT, STATE_PATHS)))
