"""Replay real cached observations under a new path, with identical source bytes.

This tests relocation, not complete-repository fingerprint reproduction. The full
reproducer separately authenticates every complete pinned repository. No current
Gold, credential, model request or original file mutation occurs in these tests.
"""

import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "core-search-pair-8"
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
plan = load(OLD / "protocol.json")
sys.path.insert(0, plan["runtime"])
from codenib.eval.benchmarks.contextbench import contextbench_prediction
from scripts.contextbench_evidence_review import confirmed_history
from scripts.contextbench_search_pair import assemble_workers

spec = importlib.util.spec_from_file_location("fixture_reproduction", ROOT / "reproduce_metrics.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.verify_runtime(OLD / "runtime-source.tar.gz", Path(plan["runtime"]), plan["runtime_source_archive_sha256"])
def verify_cached_case(case):
    src = OLD / "live" / case["language"]
    record = load(Path(case["input"]))
    end = load(src / "case-terminal.json")
    expected = load(src / "haiku_scout_pair-prediction.json")
    raw = {label: load(src / label / "trajectory.json") for label in ["first", "scout"]}
    before = copy.deepcopy(raw)
    original = Path(record["repo"])
    with tempfile.TemporaryDirectory(prefix="cb500-relocated-source-") as directory:
        target = Path(directory)
        files = expected["traj_data"]["pred_files"]
        for name in files:
            path = module.safe_path(target, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((original / name).read_bytes())
            assert sha(path) == sha(original / name)
        for label in raw:
            assert module.acknowledged(raw[label]["messages"]) == confirmed_history(raw[label]["messages"])
        pred, assembly = module.replay_case(case, end, record, raw, target, contextbench_prediction, assemble_workers)
        assert pred == expected and raw == before
        return {"instance_id": case["instance_id"], "copied_physical_source_files": len(files), "unique_source_lines_reproduced": assembly["unique_observed_source_lines"], "old_and_relocated_footprints_identical": True, "original_raw_unchanged": True}
rows = list(module.ordered_replays(plan["cases"][:2], verify_cached_case, jobs=2))
synthetic = [
    {"role": "assistant", "tool_calls": [{"id": "read", "function": {"name": "read", "arguments": json.dumps({"file_path": "/original/f.py"})}}, {"id": "grep", "function": {"name": "grep", "arguments": "{}"}}]},
    {"role": "tool", "tool_call_id": "read", "content": "1| source literal /original/keep_me\n"},
    {"role": "tool", "tool_call_id": "grep", "content": "/original/f.py:1: source literal /original/keep_me\n"},
    {"role": "assistant", "content": "ack"},
]
derived = module.rebase_history(synthetic, "/original", "/relocated")
assert json.loads(derived[0]["tool_calls"][0]["function"]["arguments"])["file_path"] == "/relocated/f.py"
assert derived[1]["content"] == synthetic[1]["content"]
assert derived[2]["content"] == "/relocated/f.py:1: source literal /original/keep_me\n"
assert synthetic[2]["content"].startswith("/original/f.py:")
for bad in ["/absolute", "../escape"]:
    try:
        module.safe_path(Path("/fixture"), bad)
    except ValueError:
        pass
    else:
        raise AssertionError("Unsafe extraction path accepted")
result = {"actual_reproduction_driver_sha256": sha(ROOT / "reproduce_metrics.py"), "cached_cases": rows, "parallel_source_replay_jobs": 2, "all1677_explicit_runtime_files_verified_against_archive": True, "path_labels_only_changed_not_source_text": True, "unsafe_archive_paths_rejected": True, "new_model_calls": 0, "new_annotation_reads": 0, "original_sources_or_raws_modified": False}
with (ROOT / "reproduction-path-verification.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
