"""Execute actual coordinator bytes with fake stages; no providers or secrets."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / "finish_pipeline.py").read_bytes()
rows = []
COMMON = '''import json,os,sys
from pathlib import Path
r=Path(__file__).resolve().parent;fault=json.loads((r/'fault.json').read_text())
with (r/'calls.jsonl').open('a') as f:f.write(json.dumps(Path(__file__).name)+'\\n')
'''
for fault in ["none", "source_failed", "source_owner_missing", "freeze_failed", "controller_failed", "missing_live_terminal"]:
    with tempfile.TemporaryDirectory(prefix="cb500-pipeline-fixture-") as directory:
        target = Path(directory)
        for name in ["finish_pipeline.py", "prepare.py", "freeze.py", "case.py", "run.py", "report.py", "postprocess.py", "design.json", "selection.json", "dispatch-verification.json", "postprocess-order-verification.json", "seal-verification.json", "freeze-preparation-gate-verification.json", "api-model-preflight.json"]:
            shutil.copyfile(ROOT / name, target / name)
        (target / "fault.json").write_text(json.dumps(fault))
        owner = subprocess.Popen([sys.executable, "-c", "pass"])
        owner.wait()
        (target / "preparation-intent.json").write_text(json.dumps({"pid": owner.pid}))
        if fault != "source_owner_missing":
            (target / "preparation-terminal.json").write_text(json.dumps({"all_ready": fault != "source_failed", "ready": 499 if fault == "source_failed" else 500, "selected": 500}))
        (target / "freeze.py").write_text(COMMON + "\nif fault=='freeze_failed':sys.exit(2)\n(r/'protocol.json').write_text(json.dumps({'python':sys.executable}))\n")
        (target / "run.py").write_text(COMMON + "\n(r/'live-intent.json').write_text(json.dumps({'pid':os.getpid()}))\nif fault=='missing_live_terminal':sys.exit(1)\n(r/'live-terminal.json').write_text(json.dumps({'state':'stopped' if fault=='controller_failed' else 'finished','known_new_API_usage_usd':.01 if fault=='controller_failed' else .02,'unknown_worker_fees':1 if fault=='controller_failed' else 0}))\nsys.exit(1 if fault=='controller_failed' else 0)\n")
        (target / "postprocess.py").write_text(COMMON + "\n(r/'postprocess-terminal.json').write_text(json.dumps({'state':'stopped_before_Gold_source_contract_failed' if fault=='controller_failed' else 'finished'}))\nsys.exit(2 if fault=='controller_failed' else 0)\n")
        result = subprocess.run([sys.executable, str(target / "finish_pipeline.py")], capture_output=True, text=True, timeout=30)
        terminal = json.loads((target / "pipeline-terminal.json").read_text())
        calls = [json.loads(line) for line in (target / "calls.jsonl").read_text().splitlines()] if (target / "calls.jsonl").exists() else []
        wanted = [] if fault in ["source_failed", "source_owner_missing"] else ["freeze.py"] if fault == "freeze_failed" else ["freeze.py", "run.py"] if fault == "missing_live_terminal" else ["freeze.py", "run.py", "postprocess.py"]
        assert calls == wanted, (fault, calls, result.stderr)
        assert terminal["state"] == ("finished_source_scored" if fault == "none" else "stopped")
        assert result.returncode == (0 if fault == "none" else 1)
        if fault in ["source_failed", "source_owner_missing", "freeze_failed"]:
            assert terminal["known_new_API_usage_usd"] == 0 and not terminal["program_fee_accounting_pending"]
        if fault == "missing_live_terminal":
            assert terminal["known_new_API_usage_usd"] is None and terminal["unknown_worker_fees"] is None and terminal["program_fee_accounting_pending"]
        if fault == "controller_failed":
            assert terminal["known_new_API_usage_usd"] == .01 and terminal["unknown_worker_fees"] == 1 and terminal["program_fee_accounting_pending"]
        rows.append({"fixture": fault, "stages_called_once_in_order": calls, "state": terminal["state"], "known_new_usage": terminal["known_new_API_usage_usd"], "unknown_fees": terminal["unknown_worker_fees"]})
out = {"actual_pipeline_driver_sha256": hashlib.sha256(source).hexdigest(), "fixtures": rows, "model_calls": 0, "real_credentials_read": False, "real_Gold_or_source_opened": False, "no_worker_restart_or_retry": True}
with (ROOT / "pipeline-verification.json").open("x") as stream:
    json.dump(out, stream, indent=2)
    stream.write("\n")
print(json.dumps(out))
