"""Verify fresh offline replay/evaluator environments on exposed source only.

Both environments exclude system-site packages. No provider SDK is installed,
and the parent removes credential variables before invoking this script. Test
two original cached observations and synthetic annotations, never canonical500
labels. All artifacts here are material-readiness evidence, not quality scores.
"""

import hashlib
import importlib.metadata
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "core-search-pair-8"
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert Path(sys.prefix) == ROOT / "replay-locked-venv"
assert "include-system-site-packages = false" in (Path(sys.prefix) / "pyvenv.cfg").read_text()
assert not any("API_KEY" in name or "AUTH_TOKEN" in name or "OAUTH_TOKEN" in name for name in os.environ)
installed = {d.metadata["Name"].lower(): d.version for d in importlib.metadata.distributions()}
assert not {"anthropic", "claude-agent-sdk", "litellm", "openai"} & set(installed)
plan = load(OLD / "protocol.json")
runtime = Path(plan["runtime"])
sys.path.insert(0, str(runtime))
from codenib.eval.benchmarks.contextbench import contextbench_prediction
from codenib.eval.benchmarks.contextbench_runner import audit_contextbench_snapshot, contextbench_evaluator_command
from codenib.source_fingerprint import fingerprint_repository
from scripts.contextbench_search_pair import assemble_workers

spec = importlib.util.spec_from_file_location("isolated_replayer", ROOT / "reproduce_metrics.py")
replayer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replayer)
replayer.verify_runtime(OLD / "runtime-source.tar.gz", runtime, plan["runtime_source_archive_sha256"])
rows, evaluation = [], []
with tempfile.TemporaryDirectory(prefix="isolated-observation-replay-", dir=ROOT) as directory:
    target = Path(directory)
    for case in plan["cases"][:2]:
        record = load(Path(case["input"]))
        original = Path(record["repo"])
        audit_contextbench_snapshot(original, case["base_commit"])
        assert fingerprint_repository(original).value == plan["source_fingerprints"][case["instance_id"]]
        folder = OLD / "live" / case["language"]
        end = load(folder / "case-terminal.json")
        expected = load(folder / "haiku_scout_pair-prediction.json")
        raw = {}
        for label in ["first", "scout"]:
            path = folder / label / "trajectory.json"
            assert sha(path) == end["workers"][label]["raw_sha256"]
            raw[label] = load(path)
        relocated = target / case["language"]
        relocated.mkdir()
        for name in expected["traj_data"]["pred_files"]:
            path = replayer.safe_path(relocated, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original / name, path)
            assert sha(path) == sha(original / name)
        prediction, assembly = replayer.replay_case(case, end, record, raw, relocated, contextbench_prediction, assemble_workers)
        assert prediction == expected
        rows.append({"source_case": case["instance_id"], "clean_pinned_original_source_fingerprint_matches": True, "relocated_source_files": len(expected["traj_data"]["pred_files"]), "observed_source_lines_match": assembly["unique_observed_source_lines"]})
        # A JavaScript-labelled task can legitimately inspect TypeScript.
        # Choose synthetic evidence by the actual file, never rewrite a path.
        supported = {".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}
        file, spans = next((name, spans) for name, spans in prediction["traj_data"]["pred_spans"].items() if Path(name).suffix in supported and spans)
        span = spans[0]
        synthetic_id = "fixture-synthetic-" + case["language"]
        derived_prediction = {**prediction, "instance_id": synthetic_id}
        evaluation.append({"repo_path": str(original), "gold": {"inst_id": synthetic_id, "original_inst_id": synthetic_id, "repo_url": case["repo_url"], "commit": case["base_commit"], "gold_ctx": [{"file": file, "start_line": span["start"], "end_line": min(span["end"], span["start"] + 4)}]}, "prediction": derived_prediction})
        if case["language"] == "python":
            # Preserve the original dot-directory fixture and its official
            # path_missing diagnostic. Add a distinct positive fixture; do
            # not remap the unavailable annotation or change original scores.
            assert file == ".azure-pipelines/scripts/publish-codecov.py"
            visible_file, visible_spans = next((name, spans) for name, spans in prediction["traj_data"]["pred_spans"].items() if name.endswith(".py") and not name.startswith(".") and spans)
            visible_span = visible_spans[0]
            visible_id = "fixture-synthetic-python-visible"
            evaluation.append({"repo_path": str(original), "gold": {"inst_id": visible_id, "original_inst_id": visible_id, "repo_url": case["repo_url"], "commit": case["base_commit"], "gold_ctx": [{"file": visible_file, "start_line": visible_span["start"], "end_line": min(visible_span["end"], visible_span["start"] + 4)}]}, "prediction": {**prediction, "instance_id": visible_id}})
    (target / "synthetic-input.json").write_text(json.dumps(evaluation))
    evaluator = ROOT / "replay-evaluator-venv/bin/python"
    original_evaluator = load(ROOT.parent / "core-search-pair-independent-32/protocol.json")
    upstream = Path(original_evaluator["evaluator_upstream"])
    for name, digest in original_evaluator["evaluator_sources"].items():
        assert sha(upstream / name) == digest
    command = contextbench_evaluator_command(upstream, str(evaluator))
    with (ROOT / "replay-environment-synthetic-evaluation.log").open("x") as log:
        result = subprocess.run([*command, "--input", str(target / "synthetic-input.json"), "--output", str(target / "synthetic-metrics.json")], stdout=log, stderr=subprocess.STDOUT, timeout=120)
    assert result.returncode == 0
    scores = load(target / "synthetic-metrics.json")
    shutil.copyfile(target / "synthetic-input.json", ROOT / "replay-environment-synthetic-input.json")
    shutil.copyfile(target / "synthetic-metrics.json", ROOT / "replay-environment-synthetic-metrics.json")
    assert len(scores["cases"]) == 3
    expectations = {"fixture-synthetic-python": (0, True), "fixture-synthetic-python-visible": (1, False), "fixture-synthetic-javascript": (1, False)}
    for row in scores["cases"]:
        coverage, missing = expectations[row["instance_id"]]
        assert "error" not in row and row["final"]["line"]["coverage"] == coverage
        assert bool(row["gold_source_issues"]) == missing
        if missing:
            assert row["gold_line_spans"] == {"azure-pipelines/scripts/publish-codecov.py": [[13, 13]]}
            assert row["gold_source_issues"][0]["reason"] == "path_missing"
proof = {"runtime_commit": plan["commit"], "replayer_sha256": sha(ROOT / "reproduce_metrics.py"), "driver_sha256": sha(Path(__file__)), "system_site_packages_enabled": False, "provider_SDK_installed": False, "provider_credential_variables_present": False, "controller_external_packages": len(installed), "controller_requirements_sha256": sha(ROOT / "replay-requirements.txt"), "evaluator_requirements_sha256": sha(ROOT / "replay-evaluator-requirements.txt"), "all1677_runtime_files_verified": True, "cached_cases": rows, "fresh_official_evaluator_nonempty_synthetic_cases_passed": 3, "synthetic_hidden_path_original_annotation_and_missing_diagnostic_preserved": True, "new_model_calls": 0, "new_real_Gold_reads": 0, "synthetic_Gold_records": 3, "actual_verified500_reproduction_completed": False}
with (ROOT / "replay-environment-verification.json").open("x") as output:
    json.dump(proof, output, indent=2)
    output.write("\n")
print(json.dumps(proof))
