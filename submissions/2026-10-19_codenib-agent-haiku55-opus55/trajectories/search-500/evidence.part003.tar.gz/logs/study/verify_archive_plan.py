"""Test complete nested-control packaging and refusal to snapshot a live owner.

Use a synthetic stopped study with zero SDK attempts and real immutable older
archive bytes. No current500 labels, source workspaces, credentials or models are
opened. All produced plans/parts stay in a temporary sibling and are removed.
"""

import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location("fixture_archive_plan", ROOT / "archive_plan.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
archive_driver = ROOT.parent / "native500-baseline/usage-audit/archive_raw.py"
required = ["design.json", "selection.json", "design-readiness.json", "prepare.py", "case.py", "run.py", "report.py", "postprocess.py", "freeze.py", "finish_pipeline.py", "api-model-preflight.json", "verify_dispatch.py", "dispatch-verification.json", "verify_postprocess.py", "postprocess-order-verification.json", "verify_seal.py", "seal-verification.json", "verify_freeze_gate.py", "freeze-preparation-gate-verification.json", "verify_pipeline.py", "pipeline-verification.json", "pipeline-handoff-verification.json", "publish.py", "archive_plan.py", "reproduce_metrics.py", "runtime-environment.json", "clean-source-reproduction-verification.json", "verify_clean_clone.py", "REPRODUCE.md", "replay-requirements.txt", "replay-evaluator-requirements.txt", "verify_replay_environment.py", "replay-environment-verification.json", "replay-environment-synthetic-input.json", "replay-environment-synthetic-metrics.json", "replay-environment-synthetic-evaluation.log", "submission-requirements-readback.json", "official-README.md", "official-submissions.mjs", "replay-environment-synthetic-input-original-hidden-source-diagnostic.json", "replay-environment-synthetic-metrics-original-hidden-source-diagnostic.json", "settle_budget.py", "verify_settlement.py", "settlement-fixture-verification.json", "settlement-live-guard-verification.json", "execution-launch-verification.json", "first-live-source-cost-observation.json", "scan_finished_trajectories.py", "audit_email_provenance.py", "finished-trajectory-privacy-initial.json", "email-provenance-initial.json", "email-unattributed-origin-initial.json", "email-encoded-query-provenance-initial.json", "email-query-artifact-match-verification.json"]
with tempfile.TemporaryDirectory(prefix="fixture-cb500-archive-", dir=ROOT.parent) as directory:
    target = Path(directory)
    for name in required:
        shutil.copyfile(ROOT / name, target / name)
    (target / "preparation.log").write_text("")
    (target / "pipeline.log").write_text("")
    (target / "pipeline-terminal.json").write_text(json.dumps({"state": "stopped"}))
    owner = subprocess.Popen([sys.executable, "-c", "import sys;sys.stdin.read()", str(target / "finish_pipeline.py")], stdin=subprocess.PIPE)
    (target / "pipeline-intent.json").write_text(json.dumps({"pid": owner.pid, "drivers": {"design.json": sha(target / "design.json"), "selection.json": sha(target / "selection.json")}}))
    dead = subprocess.Popen([sys.executable, "-c", "pass"])
    dead.wait()
    (target / "preparation-intent.json").write_text(json.dumps({"pid": dead.pid}))
    try:
        try:
            module.build_plan(target)
        except AssertionError as error:
            assert "still live" in str(error)
        else:
            raise AssertionError("An active evidence owner must block archiving")
    finally:
        owner.terminate()
        owner.wait(timeout=5)
    plan = module.build_plan(target)
    assert plan["population"] == 500 and plan["recorded_worker_intents"] == 0
    assert plan["pipeline_state"] == "stopped" and not plan["official_submission_ready"]
    nested = [m for m in plan["members"] if m["name"].startswith("logs/frozen-native500-control/")]
    assert len([m for m in nested if m["name"].endswith(".gz")]) == 8
    assert len({m["name"] for m in plan["members"]}) == len(plan["members"])
    privacy_names = ['scan_finished_trajectories.py', 'audit_email_provenance.py', 'finished-trajectory-privacy-initial.json', 'email-provenance-initial.json', 'email-unattributed-origin-initial.json', 'email-encoded-query-provenance-initial.json', 'email-query-artifact-match-verification.json']
    assert all("logs/study/" + name in {m["name"] for m in plan["members"]} for name in privacy_names)
    path = target / "archive-plan.json"
    path.write_text(json.dumps(plan))
    output = target / "test-archive"
    build = subprocess.run([sys.executable, str(archive_driver), "build", "--plan", str(path), "--output", str(output)], capture_output=True, text=True, timeout=120)
    assert build.returncode == 0, build.stderr
    check = subprocess.run([sys.executable, str(archive_driver), "verify", "--output", str(output)], capture_output=True, text=True, timeout=120)
    assert check.returncode == 0, check.stderr
    verified = load(output / "verification.json")
    assert verified["all_original_byte_hashes_match"] and verified["members_roundtrip_verified"] == len(plan["members"])
    result = {"actual_archive_plan_driver_sha256": sha(ROOT / "archive_plan.py"), "active_owner_rejected": True, "synthetic_stopped_study_population": 500, "synthetic_study_worker_attempts": 0, "original_control_parts_nested": 8, "nested_control_members_previously_verified": 2070, "outer_members_roundtrip_verified": verified["members_roundtrip_verified"], "all_original_byte_hashes_match": True, "all_parts_below_50MiB": verified["all_committed_parts_below_50MiB"], "new_model_calls": 0, "new_annotation_reads": 0, "actual_public_assets_modified": False, "initial_privacy_evidence_members_included": len(privacy_names), "privacy_scan_is_not_whole500_or_publication_approval": True}
with (ROOT / "archive-plan-fixture-verification.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
