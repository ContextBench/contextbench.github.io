"""Continue the existing source owner through one guarded primary500 execution.

Reuse the earlier benchmark's exclusive-intent/stage pattern. No locks or owner
stealing: root alone recovers interrupted phases by observing their original
process records, never restarting workers. Driver hashes stay fixed throughout.
The fsynced execution-readiness file is the paid-dispatch boundary; the fsynced
source seal is the Gold boundary. This coordinator adds no model-level retries.
"""

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
FILES = ["finish_pipeline.py", "prepare.py", "freeze.py", "case.py", "run.py", "report.py", "postprocess.py", "design.json", "selection.json", "dispatch-verification.json", "postprocess-order-verification.json", "seal-verification.json", "freeze-preparation-gate-verification.json", "api-model-preflight.json"]


def save(name, value):
    with (ROOT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    assert not (ROOT / "protocol.json").exists() and not (ROOT / "live-intent.json").exists()
    drivers = {name: sha(ROOT / name) for name in FILES}
    source = load(ROOT / "preparation-intent.json")
    source_pid = source["pid"]
    save("pipeline-intent.json", {"pid": os.getpid(), "source_pid": source_pid, "started_unix": time.time(), "drivers": drivers, "max_new_SDK_sessions": 1000, "API_guard_usd": 12, "paid_sessions_at_creation": 0, "model_retries": 0})
    stages = []
    live_entered = False

    def audit():
        for name, digest in drivers.items():
            assert sha(ROOT / name) == digest, name

    def stage(name, interpreter, filename):
        audit()
        with (ROOT / ("pipeline-" + name + ".log")).open("x") as stream:
            child = subprocess.Popen([interpreter, str(ROOT / filename)], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            save("pipeline-" + name + "-process.json", {"pid": child.pid, "started_unix": time.time(), "driver": filename})
            code = child.wait()
        stages.append({"stage": name, "exit_code": code, "completed_unix": time.time()})
        print(json.dumps(stages[-1]), flush=True)
        return code

    def terminal(state, error=None):
        live = load(ROOT / "live-terminal.json") if (ROOT / "live-terminal.json").exists() else None
        save("pipeline-terminal.json", {"state": state, "stages": stages, "error": error, "completed_unix": time.time(), "known_new_API_usage_usd": live["known_new_API_usage_usd"] if live else (None if live_entered else 0), "unknown_worker_fees": live["unknown_worker_fees"] if live else (None if live_entered else 0), "program_fee_accounting_pending": live_entered, "model_retries": 0, "repair_calls": 0})

    try:
        while not (ROOT / "preparation-terminal.json").exists():
            try:
                command = (Path("/proc") / str(source_pid) / "cmdline").read_bytes().split(b"\0")
                alive = str(ROOT / "prepare.py").encode() in command
            except FileNotFoundError:
                alive = False
            assert alive or (ROOT / "preparation-terminal.json").exists(), "Original source owner ended without terminal; inspect, never restart"
            print(json.dumps({"state": "waiting_on_existing_source_preparation", "source_pid": source_pid, "checked_unix": time.time()}), flush=True)
            time.sleep(30)
        audit()
        prep = load(ROOT / "preparation-terminal.json")
        assert prep["all_ready"] and prep["selected"] == prep["ready"] == 500
        assert stage("freeze", sys.executable, "freeze.py") == 0
        plan = load(ROOT / "protocol.json")
        live_entered = True
        code = stage("live", plan["python"], "run.py")
        assert code in (0, 1) and (ROOT / "live-terminal.json").exists(), "Missing original controller terminal; inspect original children, never retry"
        post_code = stage("postprocess", sys.executable, "postprocess.py")
        audit()
        assert post_code == 0 and load(ROOT / "postprocess-terminal.json")["state"] == "finished"
        terminal("finished_source_scored")
        return 0
    except Exception as error:
        terminal("stopped", f"{type(error).__name__}: {error}")
        raise


if __name__ == "__main__":
    sys.exit(main())
