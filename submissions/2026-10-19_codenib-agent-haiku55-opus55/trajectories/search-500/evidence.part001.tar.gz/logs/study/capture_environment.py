"""Record local tool/package versions without reading credentials or models."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior = load(ROOT.parent / "core-search-pair-independent-32/protocol.json")
probe = """import importlib.metadata as m,json,platform,sys
packages=sorted([{'name':d.metadata.get('Name',''),'version':d.version} for d in m.distributions()],key=lambda x:(x['name'].casefold(),x['version']))
print(json.dumps({'python':platform.python_version(),'implementation':platform.python_implementation(),'platform':platform.platform(),'executable':sys.executable,'packages':packages}))
"""
environments = {}
for role, python in [("controller", sys.executable), ("SDK", prior["python"]), ("evaluator", prior["evaluator_python"])]:
    result = subprocess.run([python, "-c", probe], capture_output=True, text=True, check=True, timeout=30)
    environments[role] = json.loads(result.stdout)
tools = {}
env = dict(os.environ)
env["DISABLE_AUTOUPDATER"] = "1"
for name in ["claude", "rg", "git"]:
    path = shutil.which(name)
    assert path
    result = subprocess.run([path, "--version"], capture_output=True, text=True, check=True, timeout=30, env=env)
    target = Path(path).resolve()
    tools[name] = {"resolved_path": str(target), "version_output": result.stdout.strip(), "file_sha256": sha(target) if target.is_file() else None}
assert any(p["name"].casefold() == "claude-agent-sdk" and p["version"] == "0.2.165" for p in environments["SDK"]["packages"])
assert tools["claude"]["version_output"] == "2.1.301 (Claude Code)"
result = {"captured_utc": datetime.now(timezone.utc).isoformat(), "runtime_commit": "71e489e5875ca19d73bd15c417b339fb43225439", "driver_sha256": sha(Path(__file__)), "environments": environments, "tools": tools, "environment_variable_values_or_credentials_collected": False, "model_requests": 0, "compute_costs_included_in_API_usage": False, "runtime_source_archive_verification": load(ROOT.parent / "core-search-pair-8/runtime-archive-verification.json")}
with (ROOT / "runtime-environment.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({"environments_recorded": list(environments), "package_counts": {r: len(v["packages"]) for r, v in environments.items()}, "tool_versions": {r: v["version_output"].splitlines()[0] for r, v in tools.items()}, "model_requests": 0, "credentials_collected": False}))
