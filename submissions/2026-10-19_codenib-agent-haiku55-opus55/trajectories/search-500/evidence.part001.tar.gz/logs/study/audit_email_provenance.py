"""Attribute email-like literals without emitting their values or changing logs.

Only terminal-bound trajectories from the initial scan are considered. Provenance
is either the frozen issue or exact observed line spans in a pinned public Git
blob. Unavailable module/blob paths stay unattributed. This partial contextual
check does not approve publication of SDK identifiers or workstation paths.
"""

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EMAIL = re.compile(rb"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
load = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
scan_path = ROOT / "finished-trajectory-privacy-initial.json"
scan = load(scan_path)
plan = load(ROOT / "protocol.json")
cases = {case["instance_id"]: case for case in plan["cases"]}
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
rows = []


def scalar_strings(value):
    """Formatting escapes are not part of a JSON field's actual contents."""
    if isinstance(value, str):
        yield value.encode()
    elif isinstance(value, dict):
        for key, child in value.items():
            yield str(key).encode()
            yield from scalar_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from scalar_strings(child)


for scanned in scan["rows"]:
    if not scanned["linkable_or_contextual_metadata_pattern_counts"]["email_like_literal"]:
        continue
    key, label = scanned["instance_id"], scanned["worker"]
    rawpath = ROOT / "live" / key / label / "trajectory.json"
    data = rawpath.read_bytes()
    assert sha(data) == scanned["original_sha256"]
    raw = json.loads(data)
    terminal = load(ROOT / "live" / key / "case-terminal.json")
    assert terminal["workers"][label]["raw_sha256"] == sha(data)
    record_path = Path(cases[key]["input"])
    assert sha(record_path.read_bytes()) == cases[key]["input_sha256"]
    record = load(record_path)
    serialized_candidates = set(EMAIL.findall(data))
    candidates = set(EMAIL.findall(b"\n".join(scalar_strings(raw))))
    issue = set(EMAIL.findall(record["problem_statement"].encode()))
    from_issue = candidates & issue
    from_source, evidence, unavailable = set(), [], 0
    prediction = terminal["workers"][label]["prediction"]["traj_data"]["pred_spans"]
    for name, spans in prediction.items():
        blob = subprocess.run(["git", "-C", record["repo"], "cat-file", "blob", cases[key]["base_commit"] + ":" + name], env=env, capture_output=True, timeout=30)
        if blob.returncode != 0:
            unavailable += 1
            continue
        lines = blob.stdout.splitlines()
        observed = b"\n".join(line for span in spans for line in lines[span["start"] - 1 : span["end"]])
        matched = candidates & set(EMAIL.findall(observed))
        if matched:
            from_source.update(matched)
            evidence.append({"public_source_file": name, "pinned_blob_sha256": sha(blob.stdout), "observed_spans": spans, "email_like_candidates_attributed": len(matched)})
        if candidates <= from_issue | from_source:
            break
    # Result text can quote source; other SDK terminal identity fields are
    # separate from that generated text, even if a value occurs in public code.
    sdk_identity_candidates = set()
    for field, value in (raw.get("sdk_result") or {}).items():
        if field not in {"result", "structured_output", "model_usage", "permission_denials"} and isinstance(value, str):
            sdk_identity_candidates.update(EMAIL.findall(value.encode()))
    rows.append({"instance_id": key, "worker": label, "original_raw_sha256": sha(data), "unique_email_like_candidates": len(candidates), "serialization_only_email_like_values": len(serialized_candidates - candidates), "attributed_to_frozen_public_issue": len(from_issue), "attributed_to_observed_pinned_public_source": len(from_source), "unattributed_email_like_candidates": len(candidates - from_issue - from_source), "email_like_candidates_in_nonresult_SDK_terminal_fields": len(candidates & sdk_identity_candidates), "source_blob_paths_unavailable_for_this_check": unavailable, "public_source_evidence": evidence})
    assert sha(rawpath.read_bytes()) == scanned["original_sha256"]
result = {"scope": "Partial contextual review of email-like literals in exact completed originals; values never emitted. Candidates use decoded JSON scalar strings, avoiding formatting-escape prefixes. Source proof uses only observed line spans from exact pinned public Git blobs or the frozen issue. SDK identifiers and local paths remain separate review items.", "driver_sha256": sha(Path(__file__).read_bytes()), "initial_privacy_scan_sha256": sha(scan_path.read_bytes()), "trajectories_with_email_like_literals_reviewed": len(rows), "serialization_only_email_like_value_count": sum(row["serialization_only_email_like_values"] for row in rows), "unattributed_email_like_candidate_count": sum(row["unattributed_email_like_candidates"] for row in rows), "nonresult_SDK_identity_email_like_candidate_count": sum(row["email_like_candidates_in_nonresult_SDK_terminal_fields"] for row in rows), "matched_values_emitted": False, "originals_modified": False, "new_model_calls": 0, "new_annotation_reads": 0, "contextual_privacy_review_complete": False, "raw_publication_ready": False, "rows": rows}
with (ROOT / "email-provenance-initial.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in result.items() if key != "rows"}))
