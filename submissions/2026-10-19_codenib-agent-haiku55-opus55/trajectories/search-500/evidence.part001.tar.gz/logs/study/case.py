"""Two unchanged primary search sessions on one exact canonical500 source."""
import asyncio,hashlib,importlib.metadata,json,math,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load(ROOT/'protocol.json');sys.path.insert(0,plan['runtime'])
from codenib.compiler.manifest import RepoManifest
from codenib.mcp.context import ServerContext
from codenib.source_fingerprint import capture_repository_source
from scripts import benchmark_context_claude as claude
from scripts.benchmark_jev_base import write_json
from scripts.contextbench_evidence_review import confirmed_history
from scripts.contextbench_search_pair import assemble_workers,scout_query
case=next(c for c in plan['cases'] if c['instance_id']==sys.argv[1])
for name,digest in plan['implementation'].items():assert sha(Path(plan['runtime'])/name)==digest
assert sha(Path(__file__))==plan['case_driver_sha256']
assert sha(Path(case['input']))==case['input_sha256']
record=load(Path(case['input']));assert set(record)=={'instance_id','repo','base_commit','problem_statement','language'}
repo=Path(record['repo']).resolve();output=ROOT/'live'/case['instance_id'];output.mkdir(exist_ok=False)
assert not output.is_relative_to(repo)
assert os.environ.get('CLAUDE_CODE_MAX_OUTPUT_TOKENS')=='4096'
cli=shutil.which('claude');assert importlib.metadata.version('claude-agent-sdk')=='0.2.165'
assert subprocess.check_output([cli,'--version'],text=True).strip()=='2.1.301 (Claude Code)'
auth=claude.api_auth(cli)
def save(name,value):
 with (output/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save('case-intent.json',{'instance_id':case['instance_id'],'started_unix':time.time(),'protocol_sha256':sha(ROOT/'protocol.json'),'auth':auth,'repair_calls':0})
started=time.perf_counter();binding=ctx=None;workers={};failure=None;source={};before={}
known=lambda v:type(v) in (int,float) and math.isfinite(v) and v>=0
async def run_worker(label,model,prompt):
 folder=output/label;folder.mkdir(exist_ok=False)
 row={'instance_id':case['instance_id'],'worker_label':label,'status':'running','messages':[{'role':'user','content':prompt}],'sdk_events':[],'calls':[],'source_context':source,'snapshot_before':before,'billing_route':'anthropic-api','configured_model':model}
 checkpoint=lambda:write_json(folder/'trajectory.json',row)
 with (folder/'model-intent.json').open('x') as f:json.dump({'model':model,'started_unix':time.time(),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest()},f);f.flush();os.fsync(f.fileno())
 tick=time.perf_counter();accepted=False;pred=None
 try:
  await asyncio.wait_for(claude.retrieve(repo=repo,query_text=prompt,row=row,checkpoint=checkpoint,cli=cli,model=model,max_turns=20,case_meter_usd=plan['worker_budgets'][model],billing_route='anthropic-api'),timeout=600)
  row['snapshot_after']=claude.native.audit_contextbench_snapshot(repo,record['base_commit'])
  with ctx._view_lock:
   with ctx.borrow_source_reader().read_session():pass
  end=row.get('sdk_result') or {};fee=end.get('total_cost_usd');models={e['data'].get('model') for e in row['sdk_events'] if e['kind']=='AssistantMessage'}
  inits=[e['data']['data'] for e in row['sdk_events'] if e['kind']=='SystemMessage' and e['data'].get('subtype')=='init']
  assert row['status'] in ['ok','budget_exhausted'] and models=={model}
  assert len(inits)==1 and inits[0].get('apiKeySource')=='ANTHROPIC_API_KEY'
  assert known(fee) and fee<=plan['maximum_observed_worker_usd'][model]
  assert math.isclose(sum(m['costUSD'] for m in end['model_usage'].values()),fee,abs_tol=1e-10)
  pred=claude.native.contextbench_prediction(instance_id=case['instance_id'],messages=confirmed_history(row['messages']),repo_path=repo)
  write_json(folder/'prediction.json',pred);accepted=True
 except BaseException as exc:
  row['execution_error']=f'{type(exc).__name__}: {exc}';row['status']='error';raise
 finally:
  row['elapsed_seconds']=time.perf_counter()-tick;row['accepted']=accepted;checkpoint()
  fee=row.get('sdk_reported_cost_usd')
  workers[label]={'label':label,'commit':record['base_commit'],'source_fingerprint':source.get('source_fingerprint'),'accepted':accepted,'all_model_usage_usd':fee,'prediction':pred,'configured_model':model,'raw':str(folder/'trajectory.json'),'raw_sha256':sha(folder/'trajectory.json'),'SDK_loop_seconds':(row.get('sdk_result') or {}).get('duration_ms',0)/1000}
  print(json.dumps({'worker':label,'model':model,'accepted':accepted,'fee_usd':fee}),flush=True)
async def execute():
 await run_worker('first',plan['haiku_model'],record['problem_statement'])
 query=scout_query(record['problem_statement'],workers['first']['prediction'],commit=record['base_commit'],source_fingerprint=source['source_fingerprint'],token_budget=plan['navigation_token_budget'])
 save('scout-query.json',{'query':query,'first_prediction_sha256':sha(output/'first/prediction.json'),'navigation_is_not_source_credit':True})
 await run_worker('scout',plan['haiku_model'],query)
try:
 before=claude.native.audit_contextbench_snapshot(repo,record['base_commit']);binding=capture_repository_source(repo)
 assert binding.fingerprint==plan['source_fingerprints'][case['instance_id']]
 source={'verified':True,'loaded_views':[],'source_fingerprint':binding.fingerprint,'file_count':binding.file_count,'preparation_seconds':time.perf_counter()-started}
 manifest=RepoManifest(repo_path=str(repo),commit=record['base_commit'],source_fingerprint=binding.fingerprint,file_count=binding.file_count);manifest.save(output/'repo_manifest.json');ctx=ServerContext.load(manifest,views=[],source_binding=binding);binding=None
 asyncio.run(execute())
except BaseException as exc:
 failure=f'{type(exc).__name__}: {exc}'
finally:
 for arm,labels in [('haiku_scout_pair',['first','scout'])]:
  if all(label in workers and workers[label]['accepted'] for label in labels):
   prediction,receipt=assemble_workers(case['instance_id'],[workers[label] for label in labels]);write_json(output/(arm+'-prediction.json'),prediction);write_json(output/(arm+'-receipt.json'),receipt)
 if ctx is not None:ctx.close()
 elif binding is not None:binding.close()
 save('case-terminal.json',{'instance_id':case['instance_id'],'source':source,'workers':workers,'error':failure,'all2_accepted':len(workers)==2 and all(w['accepted'] for w in workers.values()),'elapsed_seconds':time.perf_counter()-started,'completed_unix':time.time()})
if failure:raise RuntimeError(failure)
