"""After all source checks, freeze issue-only inputs and reserve paid execution.

Existing owner only. The final readiness file is written after both existing
budget views reconcile; dispatch rejects a partial freeze. If interrupted, root
must inspect existing files and reconcile the same reservation, never rerun
workers or count the reservation as actual fees. No model call is made here.
"""

import hashlib
import json
import math
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import pyarrow.dataset as ds

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/researcher/SysEvol/CodeMiner")
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (ROOT / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    design = load(ROOT / "design.json")
    selection = load(ROOT / "selection.json")
    prep = load(ROOT / "preparation-terminal.json")
    assert prep["all_ready"] and prep["selected"] == prep["ready"] == 500
    assert prep["issue_or_Gold_columns_read"] is False and prep["API_calls"] == 0
    source_intent = load(ROOT / "preparation-intent.json")
    assert source_intent["design_sha256"] == prep["design_sha256"]
    assert source_intent["selection_sha256"] == prep["selection_sha256"]
    assert source_intent["driver_sha256"] == prep["driver_sha256"]
    independent = ROOT.parent / "core-search-pair-independent-32"
    prior = load(independent / "protocol.json")
    baseline_path = Path(design["canonical500_protocol"])
    baseline = load(baseline_path)
    assert prep["design_sha256"] == selection["design_sha256"] == sha(ROOT / "design.json")
    assert prep["selection_sha256"] == sha(ROOT / "selection.json")
    assert prep["driver_sha256"] == sha(ROOT / "prepare.py")
    assert sha(baseline_path) == design["canonical500_protocol_sha256"]
    assert sha(independent / "analysis.json") == design["independent32_analysis_sha256"]
    assert load(independent / "analysis.json")["gates"]["advance_predeclared_primary_to500"]
    assert design["implementation"] == prior["implementation"] and design["commit"] == prior["commit"]
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=design["runtime"], text=True).strip() == design["commit"]
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=design["runtime"], text=True).strip()
    for name, digest in design["implementation"].items():
        assert sha(Path(design["runtime"]) / name) == digest
    dispatch = load(ROOT / "dispatch-verification.json")
    order = load(ROOT / "postprocess-order-verification.json")
    replay = load(ROOT / "seal-verification.json")
    assert dispatch["actual_dispatch_driver_sha256"] == sha(ROOT / "run.py")
    assert dispatch["case_driver_sha256"] == sha(ROOT / "case.py")
    assert len(dispatch["fixtures"]) == 7 and dispatch["new_model_calls"] == 0
    assert order["driver_sha256"] == sha(ROOT / "postprocess.py")
    assert len(order["fixtures"]) == 9 and all(r["source_outcomes_sealed"] and r["Gold_projection_reached"] == (r["fixture"] == "none") for r in order["fixtures"])
    assert replay["actual_report_driver_sha256"] == sha(ROOT / "report.py")
    assert len(replay["fixtures"]) == 5 and all(not r["Gold_opened"] for r in replay["fixtures"])
    assert next(r for r in replay["fixtures"] if r["fixture"] == "none")["accepted_configurations"] == 2
    models = load(ROOT / "api-model-preflight.json")
    assert models["inference_calls"] == 0 and set(models["models"]) == {design["haiku_model"]}
    model = models["models"][design["haiku_model"]]
    assert model["max_tokens"] >= 4096 and model["capabilities"]["effort"]["medium"]["supported"]
    states = [REPO / "verification/contextbench-first-source-24-20261016/work-status.json", REPO / "verification/contextbench-native-interim-20261017/on-demand-core-context-plan.json"]
    for path in states:
        state = load(path)
        assert state["active_API_reservation_usd"] == 0
        assert not state["search_pair_verified500"]["new_usage_accounted"]
        for key in ["known_program_api_usage_value_usd", "program_known_API_usage_value_usd", "current_known_program_API_usage_value_usd"]:
            if key in state:
                assert math.isclose(state[key], design["known_program_API_usage_usd"], abs_tol=1e-10)
    assert design["known_program_API_usage_usd"] + design["planned_API_batch_guard_usd"] <= 100
    dataset = Path(selection["dataset"])
    assert sha(dataset) == selection["dataset_sha256"]
    ids = [c["instance_id"] for c in selection["cases"]]
    assert ids == baseline["ids"] and len(ids) == len(set(ids)) == 500
    prepared = {r["instance_id"]: r for r in prep["rows"]}
    assert len(prepared) == len(prep["rows"]) == 500 and set(prepared) == set(ids)
    for case in selection["cases"]:
        ready = prepared[case["instance_id"]]
        assert ready["status"] == "ready" and ready["base_commit"] == case["base_commit"]
        assert ready["snapshot"]["commit"] == case["base_commit"] and ready["file_count"] > 0
        assert load(ROOT / "preparation" / (case["instance_id"] + ".json")) == ready
    columns = ["instance_id", "original_inst_id", "repo", "repo_url", "base_commit", "language", "problem_statement"]
    save("issue-access.json", {"selected_ids": ids, "columns": columns, "opened_utc": datetime.now(timezone.utc).isoformat(), "source_preparation_terminal_sha256": sha(ROOT / "preparation-terminal.json"), "annotation_columns_read": False, "population_already_exposed": True})
    rows = ds.dataset(dataset, format="parquet").to_table(columns=columns, filter=ds.field("instance_id").isin(ids)).to_pylist()
    by = {r["instance_id"]: r for r in rows}
    assert len(rows) == len(by) == 500 and set(by) == set(ids)
    parent = {}

    def find(key):
        parent.setdefault(key, key)
        if parent[key] != key:
            parent[key] = find(parent[key])
        return parent[key]

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[max(a, b)] = min(a, b)

    for case in selection["cases"]:
        node = "id:" + case["instance_id"]
        for alias in ["repo:" + case["repo"].casefold().removesuffix(".git").rstrip("/"), "url:" + case["repo_url"].casefold().removesuffix(".git").rstrip("/"), "commit:" + case["base_commit"], "original:" + case["original_inst_id"]]:
            union(node, alias)
    cases, fingerprints = [], {}
    (ROOT / "inputs").mkdir(exist_ok=False)
    for case in selection["cases"]:
        key = case["instance_id"]
        row = by[key]
        assert all(row[k] == case[k] for k in columns if k != "problem_statement")
        assert isinstance(row["problem_statement"], str) and row["problem_statement"].strip()
        ready = prepared[key]
        path = ROOT / "inputs" / (key + ".json")
        record = {"instance_id": key, "repo": ready["repo_path"], "base_commit": case["base_commit"], "problem_statement": row["problem_statement"], "language": case["language"]}
        with path.open("x") as stream:
            json.dump(record, stream, indent=2)
            stream.write("\n")
        cases.append({**case, "input": str(path), "input_sha256": sha(path), "repo_alias_cluster": find("id:" + key), "preparation_receipt_sha256": sha(ROOT / "preparation" / (key + ".json"))})
        fingerprints[key] = ready["source_fingerprint"]
    plan = {key: design[key] for key in ["scope", "runtime", "commit", "implementation", "haiku_model", "worker_budgets", "maximum_observed_worker_usd", "navigation_token_budget", "worker_order", "case_concurrency", "population", "max_actual_SDK_sessions", "effort", "max_turns_per_worker", "requested_output_tokens"]}
    plan.update(frozen_utc=datetime.now(timezone.utc).isoformat(), design_sha256=sha(ROOT / "design.json"), selection_sha256=sha(ROOT / "selection.json"), source_preparation_terminal_sha256=sha(ROOT / "preparation-terminal.json"), issue_access_sha256=sha(ROOT / "issue-access.json"), python=prior["python"], cases=cases, source_fingerprints=fingerprints, arms={"haiku_scout_pair": ["first", "scout"]}, API_batch_guard_usd=12, SDK_guard_is_account_cash_cap=False, baseline_analysis=str(ROOT.parent / "native500-baseline/analysis.json"), baseline_analysis_sha256=sha(ROOT.parent / "native500-baseline/analysis.json"), baseline_protocol_sha256=sha(baseline_path), dataset=str(dataset), dataset_sha256=sha(dataset), program_known_API_usage_before_usd=design["known_program_API_usage_usd"], API_ceiling_usd=100, runtime_source_archive=prior["runtime_source_archive"], runtime_source_archive_sha256=prior["runtime_source_archive_sha256"], independent_validation=False, known500_population=True, policy_retries=0, replacement_tasks=0, repair_calls=0, Jev_requests=0, all_new_source_outcomes_before_known500_Gold=True)
    for key in ["evaluator_upstream", "evaluator_python", "evaluator_sources"]:
        plan[key] = baseline[key]
    for name, field in [("case.py", "case_driver_sha256"), ("run.py", "driver_sha256"), ("report.py", "report_driver_sha256"), ("postprocess.py", "postprocess_driver_sha256"), ("freeze.py", "freeze_driver_sha256"), ("dispatch-verification.json", "dispatch_verification_sha256"), ("postprocess-order-verification.json", "postprocess_order_verification_sha256"), ("seal-verification.json", "seal_verification_sha256"), ("api-model-preflight.json", "model_metadata_preflight_sha256")]:
        plan[field] = sha(ROOT / name)
    plan["bootstrap"] = {"clusters": len({c["repo_alias_cluster"] for c in cases}), "resamples": 10000, "seed": 20261020, "kind": "paired repository-alias percentile95 unadjusted", "independent_generalization_claim": False}
    save("protocol.json", plan)
    save("budget-reservation.json", {"state": "reserved", "reservation_usd": 12, "known_program_API_usage_usd_before": design["known_program_API_usage_usd"], "remaining_unreserved_API_allowance_usd": 100 - design["known_program_API_usage_usd"] - 12, "protocol_sha256": sha(ROOT / "protocol.json"), "paid_calls_at_freeze": 0, "repair_calls": 0})
    for path in states:
        state = load(path)
        assert state["active_API_reservation_usd"] == 0
        state["active_API_reservation_usd"] = 12
        state["remaining_unreserved_API_allowance_usd"] = 100 - design["known_program_API_usage_usd"] - 12
        state["search_pair_verified500"].update(state="all500_sources_ready_execution_frozen_not_dispatched", execution_protocol_frozen=True, protocol_sha256=sha(ROOT / "protocol.json"), new_issue_inputs_projected=500, known500_Gold_reopened=False, active_API_reservation_usd=12, source_preparation_terminal=True)
        state["current_next_action"] = "Dispatch frozen canonical500 once: first+scout only,1000 SDK sessions max,8case windows,12USD guard, program100USD cap. No retries/replacements/repairs. Seal500 configuration and1000 worker positions before known500 Gold. Historical native500 failure/unknown fee/timing disclosure unchanged. Goal ACTIVE."
        temp = path.with_name(path.name + ".freeze-tmp")
        with temp.open("w") as stream:
            json.dump(state, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    for path in states:
        state = load(path)
        assert state["active_API_reservation_usd"] == 12 and state["search_pair_verified500"]["protocol_sha256"] == sha(ROOT / "protocol.json")
    save("execution-readiness.json", {"protocol_sha256": sha(ROOT / "protocol.json"), "all500_sources_ready": True, "budget_views_reconciled": True, "source_policy_unchanged_from_independent32": True, "dispatch_fixtures": 7, "source_Gold_order_fixtures": 9, "source_seal_replays": 5, "known500_Gold_reopened": False, "new_model_calls": 0, "API_reservation_usd": 12})
    print(json.dumps({"population": 500, "protocol_sha256": sha(ROOT / "protocol.json"), "API_reservation_usd": 12, "new_model_calls": 0, "Gold_reopened": False}))


if __name__ == "__main__":
    main()
