# Canonical500 source-search reproduction

This local evidence bundle preserves the completed primary Haiku search pair
on the same known canonical500 tasks as the older native control. All1,000
sessions are recorded and scored; line Recall is77.06906156843804%, F1
28.161839002407457%, search usage$5.680771745. The source seal predates the
same500 annotation reopening. This is not independent500 validation, solver
Pass@1 or an accepted leaderboard submission. Fees are settled once against
the existing program ledgers; no new repair models are invoked by this bundle.

The final non-source-git-metadata-audit.json discloses six candidate tasks with
seven predicted Git metadata lines. Those paths have no Gold matches but can
carry local metadata, and their bytes are not authenticated by the public source
fingerprint. Original trajectories and metrics are preserved. Fresh public
clones can therefore fail strict whole-trace replay despite matching source
fingerprints. Do not weaken assertions, omit cases/observations or replace the
original score to claim a clean replay. Any successful replay against existing
original checkouts remains distinct from fresh-clone portability.

## Original bytes and extraction

Keep every bounded gzip part, archive-index.json and verification.json. Extract
into a new empty directory in zero-padded filename order:

```bash
mkdir /path/to/bundle
gzip -dc /path/to/archive/logs.tar.part*.gz | tar -xf - -C /path/to/bundle
gzip -dc /path/to/archive/trajectories.tar.part*.gz | tar -xf - -C /path/to/bundle
cp /path/to/archive/archive-index.json /path/to/archive/verification.json /path/to/bundle/
```

The replay command verifies every extracted original member against the index
and its original round-trip receipt before loading the runtime. The complete
older native500 control is nested under logs/frozen-native500-control with its
own unchanged index, verification receipt and eight gzip parts. Its original
failed source position and unknown fee remain unchanged; do not turn unknown
usage into zero or divide partial known fees to claim a complete cost ratio.

## Compatible environment and source

logs/study/runtime-environment.json records Python, installed distribution
versions and tool versions for the controller, SDK and evaluator environments.
The inventory includes environment overlays; it is not a minimal requirements
lock or a container image. logs/runtime/runtime-source.tar.gz preserves all1,677
files of runtime71e489e5875ca19d73bd15c417b339fb43225439. The replayer extracts
and verifies that runtime by default. A supplied --runtime is checked file by
file against the same archive. The29 pinned official evaluator Python files
are under logs/pinned-evaluator; use a compatible evaluator environment from
the recorded inventory. No provider API key is required for replay.

The standalone replay environment has46 external packages; the official evaluator
has36. Their complete pinned requirement files are under logs/study. These were
installed into fresh Python3.11.5 environments without system-site packages,
then checked for dependency consistency. The replay environment has no provider
SDK or credential variables. Actual cached Python/JavaScript footprints and
three nonempty synthetic official-evaluator cases pass. The original hidden
directory normalization/missing-source case stays in that synthetic fixture,
with its annotation and missing diagnostic preserved. These setup checks are
not a completed500 replay or an estimate of retrieval/repair quality.

For example, with uv available and an installed Python3.11.5:

```bash
uv venv --python 3.11.5 /path/to/replay-env
uv pip install --python /path/to/replay-env/bin/python --no-deps -r /path/to/bundle/logs/study/replay-requirements.txt
uv pip check --python /path/to/replay-env/bin/python
uv venv --python 3.11.5 /path/to/evaluator-env
uv pip install --python /path/to/evaluator-env/bin/python --no-deps -r /path/to/bundle/logs/study/replay-evaluator-requirements.txt
uv pip check --python /path/to/evaluator-env/bin/python
```

Provide a JSON object mapping every public task ID to its existing clean exact
repository. Each pinned Git commit, declared module state and full source
fingerprint must match the original protocol. Alternatively use --repos
/path/to/new-repos --prepare-repos: the same public clone/submodule helper
fetches pinned commits. That option uses Git/network/disk but no model calls.
Unregistered Git links remain empty and explicitly unavailable, as originally.

```bash
/path/to/replay-env/bin/python /path/to/bundle/logs/study/reproduce_metrics.py \
  --bundle /path/to/bundle \
  --repo-map /path/to/task-repositories.json \
  --jobs 4 \
  --evaluator-python /path/to/pinned-evaluator-env/bin/python \
  --output /path/to/new-reproduction-output
```

`--jobs` selects1-16 independent source-replay workers (default1). Results
remain in protocol order. A failed check cancels queued work; the official
evaluator runs once after all source checks succeed.

Only derived read arguments, grep path labels and evaluator repo paths change.
Source text, original trajectories, annotations, outcomes and fee records are
never edited. Unacknowledged tool tails do not earn source credit. The script
reconstructs first/scout observations and their authenticated union and checks
every case file/symbol/line Recall, precision and F1 against the original
analysis. It does not retry searches, issue new provider requests, repair code
or establish native issue-resolution outcomes.

## Release boundary

The bundle is local until contextual privacy review. Source/metric replay does
not prove new-model reproducibility, account cash/credit reconciliation, native
Pass@1 or maintainer acceptance. Preserve original exposure and annotation
timing disclosures when presenting a same500 comparison.
