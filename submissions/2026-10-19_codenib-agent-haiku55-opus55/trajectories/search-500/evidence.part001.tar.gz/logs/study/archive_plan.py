"""Exact local candidate500 evidence plus the complete frozen native control.

Build only after coordinator termination. Never traverse homes, credentials or
repository workspaces. Include actual existing attempts and explicit sealed
unclaimed positions; do not manufacture trajectories for failed/missing workers.
Native-control parts remain original bounded gzip files inside this local bundle.
"""

import hashlib
import json
import os
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def build_plan(root):
    terminal = load(root / "pipeline-terminal.json")
    selection = load(root / "selection.json")
    design = load(root / "design.json")
    ids = [case["instance_id"] for case in selection["cases"]]
    assert len(ids) == len(set(ids)) == design["population"] == 500
    protected = load(root / "pipeline-intent.json")["drivers"]
    assert protected["design.json"] == sha(root / "design.json")
    assert protected["selection.json"] == sha(root / "selection.json")
    canonical = load(Path(design["canonical500_protocol"]))
    assert sha(Path(design["canonical500_protocol"])) == design["canonical500_protocol_sha256"]
    assert ids == canonical["ids"]
    for pid_file, pid_field, script in [("pipeline-intent.json", "pid", "finish_pipeline.py"), ("preparation-intent.json", "pid", "prepare.py")]:
        pid = load(root / pid_file)[pid_field]
        command = Path("/proc") / str(pid) / "cmdline"
        assert not command.exists() or str(root / script).encode() not in command.read_bytes().split(b"\0"), "Original evidence owner is still live"
    members = []

    def add(path, name, category="logs", optional=False):
        if optional and not path.exists():
            return
        assert path.is_file() and not path.is_symlink(), str(path)
        safe = PurePosixPath(name)
        assert not safe.is_absolute() and ".." not in safe.parts
        members.append({"source": str(path), "name": category + "/" + name, "category": category, "bytes": path.stat().st_size, "sha256": sha(path)})

    required = ["design.json", "selection.json", "design-readiness.json", "prepare.py", "preparation-intent.json", "preparation.log", "case.py", "run.py", "report.py", "postprocess.py", "freeze.py", "finish_pipeline.py", "pipeline-intent.json", "pipeline-terminal.json", "pipeline.log", "api-model-preflight.json", "verify_dispatch.py", "dispatch-verification.json", "verify_postprocess.py", "postprocess-order-verification.json", "verify_seal.py", "seal-verification.json", "verify_freeze_gate.py", "freeze-preparation-gate-verification.json", "verify_pipeline.py", "pipeline-verification.json", "pipeline-handoff-verification.json", "publish.py", "archive_plan.py"]
    for name in required:
        add(root / name, "study/" + name)
    optional = ["execution-launch-verification.json", "first-live-source-cost-observation.json", "preparation-terminal.json", "issue-access.json", "protocol.json", "execution-readiness.json", "budget-reservation.json", "budget-reservation-closure.json", "budget-settlement-verification.json", "live-intent.json", "live-terminal.json", "sealed-comparison.json", "annotation-access.json", "analysis.json", "postprocess-intent.json", "postprocess-terminal.json", "public-export-verification.json", "haiku_scout_pair-evaluation-input.json", "haiku_scout_pair-metrics.json", "haiku_scout_pair-evaluation.log", "verify_public_export.py", "public-export-fixture-verification.json", "capture_environment.py", "runtime-environment.json", "reproduce_metrics.py", "verify_reproduction_paths.py", "reproduction-path-verification.json", "reproduction-verification.json", "verify_clean_clone.py", "clean-source-reproduction-verification.json", "REPRODUCE.md", "replay-requirements.txt", "replay-evaluator-requirements.txt", "verify_replay_environment.py", "replay-environment-verification.json", "replay-environment-synthetic-input.json", "replay-environment-synthetic-metrics.json", "replay-environment-synthetic-evaluation.log", "submission-requirements-readback.json", "official-README.md", "official-submissions.mjs", "replay-environment-synthetic-input-original-hidden-source-diagnostic.json", "replay-environment-synthetic-metrics-original-hidden-source-diagnostic.json", "settle_budget.py", "verify_settlement.py", "settlement-fixture-verification.json", "settlement-live-guard-verification.json", "verify_archive_plan.py", "archive-plan-fixture-verification.json", "source_availability.py", "source-availability-audit.json", "source_gap.py", "source-gap-audit.json", "scan_finished_trajectories.py", "audit_email_provenance.py", "finished-trajectory-privacy-initial.json", "email-provenance-initial.json", "email-unattributed-origin-initial.json", "email-encoded-query-provenance-initial.json", "email-query-artifact-match-verification.json", "finished-trajectory-privacy-final500.json", "raw-contextual-privacy-review-final500.json"]
    for name in optional:
        add(root / name, "study/" + name, optional=True)
    for name in [
        "audit_email_provenance_final500.py",
        "audit_email_query_provenance_final500.py",
        "email-provenance-final500.json",
        "email-query-provenance-final500.json",
        "non-source-git-metadata-audit.json",
        "scored500-and-git-metadata-audit-handoff.json",
        "metadata-native-pilot-pool-before500scores.json",
        "native-pilot-actual-search-handoff-verification.json",
        "native-source-image-case-matching.json",
        "local-native-image-inventory.json",
        "local-pair-solver-handoff-final-verification.json",
        "public-export-fixture-verification-before-git-audit.json",
    ]:
        add(root / name, "study/" + name, optional=True)
    for stage in ["freeze", "live", "postprocess"]:
        for suffix in [".log", "-process.json"]:
            name = "pipeline-" + stage + suffix
            add(root / name, "study/" + name, optional=True)
    recorded = 0
    for case in selection["cases"]:
        key = case["instance_id"]
        add(root / "preparation" / (key + ".json"), "preparation/" + key + ".json", optional=True)
        add(root / "inputs" / (key + ".json"), "inputs/" + key + ".json", optional=True)
        folder = root / "live" / key
        for name in ["case-intent.json", "case-terminal.json", "repo_manifest.json", "scout-query.json", "haiku_scout_pair-prediction.json", "haiku_scout_pair-receipt.json"]:
            add(folder / name, "cases/" + key + "/" + name, optional=True)
        for label in ["first", "scout"]:
            recorded += (folder / label / "model-intent.json").exists()
            for name in ["trajectory.json", "prediction.json", "model-intent.json"]:
                add(folder / label / name, key + "/" + label + "/" + name, category="trajectories", optional=True)
        for suffix in ["-dispatch.json", "-process.json", ".log"]:
            add(root / "live" / (key + suffix), "execution/" + key + suffix, optional=True)
    runtime = root.parent / "core-search-pair-8"
    for name in ["runtime-source.tar.gz", "runtime-archive-verification.json"]:
        add(runtime / name, "runtime/" + name)
    independent = root.parent / "core-search-pair-independent-32"
    for name in ["protocol.json", "analysis.json", "budget-reservation-closure.json", "canonical500-cost-scenarios.json"]:
        add(independent / name, "independent32/" + name)
    baseline = root.parent / "native500-baseline"
    for name in ["protocol.json", "analysis.json", "metrics.json", "confirmed-native-predictions.json", "annotation-access.json"]:
        add(baseline / name, "baseline/" + name)
    control = root.parent / "raw-archives-extra/native500-control"
    index = load(control / "archive-index.json")
    verification = load(control / "verification.json")
    assert verification["archive_index_sha256"] == sha(control / "archive-index.json")
    assert verification["members_roundtrip_verified"] == 2070 and verification["all_original_byte_hashes_match"]
    for name in ["archive-index.json", "verification.json"]:
        add(control / name, "frozen-native500-control/" + name)
    for stream in index["streams"].values():
        for part in stream["parts"]:
            path = control / part["path"]
            assert sha(path) == part["sha256"] and path.stat().st_size < 50 * 1024 * 1024
            add(path, "frozen-native500-control/" + part["path"])
    protocol = load(root / "protocol.json") if (root / "protocol.json").exists() else load(independent / "protocol.json")
    for name, digest in protocol["evaluator_sources"].items():
        path = Path(protocol["evaluator_upstream"]) / name
        assert sha(path) == digest
        add(path, "pinned-evaluator/" + name)
    assert len({m["name"] for m in members}) == len(members)
    return {"scope": "Complete local candidate500 source-search evidence plus original frozen native500-control archive. Actual attempts only; failed/unclaimed positions remain explicit. Contextual privacy review, native issue-resolution and official submission remain open. Not publication authorization.", "members": members, "pipeline_state": terminal["state"], "design_sha256": sha(root / "design.json"), "selection_sha256": sha(root / "selection.json"), "runtime_commit": design["commit"], "population": 500, "recorded_worker_intents": recorded, "max_actual_worker_sessions": 1000, "original_native_control_members": 2070, "original_native_control_parts_included": True, "new_model_calls": 0, "official_submission_ready": False}


if __name__ == "__main__":
    result = build_plan(ROOT)
    with (ROOT / "archive-plan.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({"members": len(result["members"]), "recorded_worker_intents": result["recorded_worker_intents"], "pipeline_state": result["pipeline_state"], "new_model_calls": 0}))
