"""Authenticate complete existing canonical500 sources with no issue/Gold read.

Reuse only the exact baseline source directories. Never reset, edit or duplicate
repositories. HEAD and the full source binding must both match. Preparation has
no provider client, credentials, model dispatch or paid budget reservation.
"""

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
design = load(ROOT / "design.json")
selection = load(ROOT / "selection.json")
assert selection["design_sha256"] == sha(ROOT / "design.json")
sys.path.insert(0, design["runtime"])
from codenib.eval.benchmarks.contextbench_runner import audit_contextbench_snapshot
from codenib.source_fingerprint import capture_repository_source


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def run(case):
    started = time.perf_counter()
    result = {
        key: case[key]
        for key in ["instance_id", "language", "base_commit", "source_repo"]
    }
    try:
        repo = Path(case["source_repo"]).resolve(strict=True)
        snapshot = audit_contextbench_snapshot(repo, case["base_commit"])
        binding = capture_repository_source(repo)
        try:
            result.update(status="ready", repo_path=str(repo), snapshot=snapshot,
                          source_fingerprint=binding.fingerprint,
                          file_count=binding.file_count)
        finally:
            binding.close()
    except Exception as error:
        result.update(status="error", error=f"{type(error).__name__}: {error}")
    result["preparation_seconds"] = time.perf_counter() - started
    save(ROOT / "preparation" / (case["instance_id"] + ".json"), result)
    print(json.dumps({key: value for key, value in result.items() if key != "snapshot"}), flush=True)
    return result


save(ROOT / "preparation-intent.json", {
    "pid": os.getpid(), "started_unix": time.time(),
    "design_sha256": sha(ROOT / "design.json"),
    "selection_sha256": sha(ROOT / "selection.json"),
    "driver_sha256": sha(Path(__file__)), "API_calls": 0,
    "issue_or_Gold_columns_read": False, "source_repositories_mutated": False,
})
(ROOT / "preparation").mkdir(exist_ok=False)
with ThreadPoolExecutor(max_workers=design["source_preparation_concurrency"]) as pool:
    rows = list(pool.map(run, selection["cases"]))
ready = sum(row["status"] == "ready" for row in rows)
save(ROOT / "preparation-terminal.json", {
    "selected": 500, "ready": ready, "all_ready": ready == 500, "rows": rows,
    "design_sha256": sha(ROOT / "design.json"),
    "selection_sha256": sha(ROOT / "selection.json"),
    "driver_sha256": sha(Path(__file__)), "terminal_unix": time.time(),
    "issue_or_Gold_columns_read": False, "API_calls": 0,
})
assert ready == 500
