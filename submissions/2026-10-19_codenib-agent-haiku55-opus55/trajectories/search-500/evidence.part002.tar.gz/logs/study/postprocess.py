"""Existing controller owns requests; a durable complete source seal gates Gold.

Wait for that exact process using the OS. Never steal an owner, retry workers or
replace cases. The fsynced source seal is the ordering boundary; source/fee or
cardinality failures retain every position and stop before annotation projection.
"""

import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (ROOT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def source_gate(plan, terminal, seal):
    ids = {c["instance_id"] for c in plan["cases"]}
    positions = [(r["instance_id"], r["arm"]) for r in seal["receipts"]]
    expected = {(key, "haiku_scout_pair") for key in ids}
    workers = [(r["instance_id"], r["worker"]) for r in seal["worker_positions"]]
    expected_workers = {(key, label) for key in ids for label in plan["worker_order"]}
    return (
        terminal["state"] == "finished"
        and len(terminal["rows"]) == len(ids)
        and {r["instance_id"] for r in terminal["rows"]} == ids
        and all(r["accepted"] is True for r in terminal["rows"])
        and not terminal["unclaimed_ids"]
        and terminal["unknown_worker_fees"] == 0
        and seal["new_annotation_reads_at_freeze"] == 0
        and not seal["protocol_integrity_errors"]
        and len(positions) == len(expected) and set(positions) == expected
        and all(r["accepted"] is True and not r["integrity_errors"] for r in seal["receipts"])
        and len(workers) == len(expected_workers) and set(workers) == expected_workers
        and all(r["accepted"] is True and r["dispatched"] is True and not r["unknown_fee"] and type(r["fee_usd"]) in (int, float) and math.isfinite(r["fee_usd"]) and r["fee_usd"] >= 0 and r["raw_sha256"] for r in seal["worker_positions"])
    )


def main():
    plan = load(ROOT / "protocol.json")
    assert sha(Path(__file__)) == plan["postprocess_driver_sha256"]
    intent = load(ROOT / "live-intent.json")
    save("postprocess-intent.json", {"controller_pid": intent["pid"], "consumer_pid": os.getpid(), "started_unix": time.time(), "driver_sha256": sha(Path(__file__)), "model_calls": 0})
    subprocess.run(["tail", "--pid=" + str(intent["pid"]), "--sleep-interval=1", "-f", "/dev/null"], check=True)
    terminal = load(ROOT / "live-terminal.json")
    subprocess.run([sys.executable, str(ROOT / "report.py"), "freeze"], check=True)
    seal = load(ROOT / "sealed-comparison.json")
    if not source_gate(plan, terminal, seal):
        save("postprocess-terminal.json", {"state": "stopped_before_Gold_source_contract_failed", "source_outcomes_sealed": True, "Gold_opened": False, "model_calls": 0, "completed_unix": time.time()})
        return 2
    subprocess.run([sys.executable, str(ROOT / "report.py"), "evaluate"], check=True)
    save("postprocess-terminal.json", {"state": "finished", "all_source_positions_sealed_before_known500_Gold": True, "analysis_sha256": sha(ROOT / "analysis.json"), "source_seal_sha256": sha(ROOT / "sealed-comparison.json"), "model_calls": 0, "completed_unix": time.time()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
