"""Check only terminal-bound original trajectories; emit counts, never values.

This is a local publication preflight on completed cases, not release approval.
It never opens running checkpoints, source workspaces, annotations or providers.
Original bytes and their worker receipt hashes remain unchanged. Local paths,
public source examples/emails and SDK identifiers need contextual review.
"""

import argparse
import hashlib
import json
import os
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent


def scan(root):
    plan = json.loads((root / "protocol.json").read_text())
    selected = {case["instance_id"] for case in plan["cases"]}
    assert len(selected) == plan["population"] == 500
    completed = []
    for path in sorted((root / "live").glob("*/case-terminal.json")):
        try:
            terminal = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue  # The producer may still be fsyncing a new terminal.
        assert path.parent.name in selected
        if terminal.get("all2_accepted") is True:
            completed.append((path.parent.name, terminal))
    secret = dotenv_values("/home/researcher/.config/secrets.env", interpolate=False).get("ANTHROPIC_API_KEY")
    assert secret
    secret = secret.encode()
    credentials = {
        "anthropic_token_shape": rb"sk-ant-(?:api|oat)[A-Za-z0-9_-]{20,}",
        "openai_project_token_shape": rb"sk-proj-[A-Za-z0-9_-]{20,}",
        "github_token_shape": rb"(?:github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,})",
        "private_key_block": rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "literal_bearer_header": rb'"[Aa]uthorization"\s*:\s*"Bearer [A-Za-z0-9._-]{20,}"',
    }
    metadata = {
        "researcher_home_or_mount_path": rb"/(?:home|mnt/(?:data|conda))/zhongming(?:/|\\/)",
        "temporary_runtime_path": rb"/tmp/codenib-contextbench",
        "email_like_literal": rb"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        "SDK_session_or_user_field": rb'"(?:session_id|sessionId|user_id|userID)"\s*:',
    }
    credential_files, metadata_files = Counter(), Counter()
    rows, total_bytes = [], 0
    for key, terminal in completed:
        for label in ["first", "scout"]:
            path = root / "live" / key / label / "trajectory.json"
            assert not path.is_symlink()
            data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            assert digest == terminal["workers"][label]["raw_sha256"]
            hits = {name: len(re.findall(pattern, data)) for name, pattern in credentials.items()}
            hits["current_anthropic_key_exact"] = data.count(secret)
            contextual = {name: len(re.findall(pattern, data)) for name, pattern in metadata.items()}
            credential_files.update(name for name, count in hits.items() if count)
            metadata_files.update(name for name, count in contextual.items() if count)
            total_bytes += len(data)
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
            rows.append({"instance_id": key, "worker": label, "original_sha256": digest, "original_bytes": len(data), "credential_pattern_counts": hits, "linkable_or_contextual_metadata_pattern_counts": contextual})
    return {
        "scope": "Local automated preflight of only accepted completed-case original first/scout trajectories, verified against their exact terminal worker receipts. Count-only output; source examples and linkable metadata still require contextual review. Not publication authorization or whole500 completion.",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "protocol_sha256": hashlib.sha256((root / "protocol.json").read_bytes()).hexdigest(),
        "completed_accepted_cases_scanned": len(completed),
        "original_trajectories_verified_and_scanned": len(rows),
        "original_bytes_scanned": total_bytes,
        "credential_pattern_file_counts": {name: credential_files[name] for name in [*credentials, "current_anthropic_key_exact"]},
        "linkable_or_contextual_metadata_file_counts": {name: metadata_files[name] for name in metadata},
        "matched_values_emitted": False,
        "originals_modified": False,
        "running_checkpoints_read": False,
        "contextual_privacy_review_complete": False,
        "raw_publication_ready": False,
        "new_model_calls": 0,
        "new_annotation_reads": 0,
        "rows": rows,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = scan(ROOT)
    with args.output.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({name: value for name, value in result.items() if name != "rows"}))
