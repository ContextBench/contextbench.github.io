"""Once-only fixed500 dispatch; eight-case windows and all actual worker fees."""
import concurrent.futures,hashlib,json,math,os,subprocess,time
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load(ROOT/'protocol.json');runtime=Path(plan['runtime'])
assert sha(Path(__file__))==plan['driver_sha256'] and sha(ROOT/'case.py')==plan['case_driver_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=runtime,text=True).strip()==plan['commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=runtime,text=True).strip()
for name,digest in plan['implementation'].items():assert sha(runtime/name)==digest
def save(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
reservation=load(ROOT/'budget-reservation.json')
assert reservation['state']=='reserved' and reservation['protocol_sha256']==sha(ROOT/'protocol.json')
assert reservation['reservation_usd']==plan['API_batch_guard_usd'] and reservation['known_program_API_usage_usd_before']+reservation['reservation_usd']<=100
readiness=load(ROOT/'execution-readiness.json')
assert readiness['protocol_sha256']==sha(ROOT/'protocol.json') and readiness['all500_sources_ready'] is True and readiness['budget_views_reconciled'] is True
save(ROOT/'live-intent.json',{'pid':os.getpid(),'started_unix':time.time(),'protocol_sha256':sha(ROOT/'protocol.json'),'new_SDK_sessions_max':1000,'model_retries':0})
(ROOT/'live').mkdir(exist_ok=False)
env=dict(os.environ)
for name in ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','ANTHROPIC_BASE_URL','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_USE_BEDROCK','CLAUDE_CODE_USE_VERTEX','CLAUDE_CODE_USE_FOUNDRY','OPENAI_API_KEY','OPENROUTER_API_KEY','ANTHROPIC_MODEL','ANTHROPIC_DEFAULT_HAIKU_MODEL','ANTHROPIC_DEFAULT_SONNET_MODEL','ANTHROPIC_DEFAULT_OPUS_MODEL','CLAUDE_CODE_SUBAGENT_MODEL']:env.pop(name,None)
key=dotenv_values('/home/researcher/.config/secrets.env',interpolate=False).get('ANTHROPIC_API_KEY');assert key;env['ANTHROPIC_API_KEY']=key
env.update(CLAUDE_CODE_MAX_OUTPUT_TOKENS='4096',DISABLE_AUTOUPDATER='1',GIT_OPTIONAL_LOCKS='0',TMPDIR='/mnt/data/researcher/.cbtmp310',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
known=lambda v:type(v) in (int,float) and math.isfinite(v) and v>=0
def run(case):
 lang=case['instance_id'];save(ROOT/'live'/(lang+'-dispatch.json'),{'instance_id':case['instance_id'],'started_unix':time.time()})
 with (ROOT/'live'/(lang+'.log')).open('x') as f:
  child=subprocess.Popen([plan['python'],str(ROOT/'case.py'),lang],cwd=runtime,env=env,stdout=f,stderr=subprocess.STDOUT);save(ROOT/'live'/(lang+'-process.json'),{'pid':child.pid,'started_unix':time.time()})
  try:code=child.wait(timeout=2700)
  except subprocess.TimeoutExpired:child.kill();code=child.wait()
 folder=ROOT/'live'/lang;parse_errors=[]
 def terminal_json(path):
  if not path.exists():return {}
  try:return load(path)
  except (OSError,ValueError) as exc:
   parse_errors.append({'path':str(path.relative_to(ROOT)),'error':type(exc).__name__});return {}
 terminal=terminal_json(folder/'case-terminal.json');workers=terminal.get('workers',{})
 fees=[];unknown=0
 for label in ['first','scout']:
  p=folder/label/'trajectory.json';raw=terminal_json(p);dispatched=(folder/label/'model-intent.json').exists();fee=raw.get('sdk_reported_cost_usd') if dispatched else 0
  fees.append(fee)
  if dispatched and not known(fee):unknown+=1
 accepted=code==0 and terminal.get('all2_accepted') is True and unknown==0 and not parse_errors
 out={'instance_id':case['instance_id'],'language':case['language'],'exit_code':code,'accepted':accepted,'known_actual_SDK_usage_usd':sum(f for f in fees if known(f)),'unknown_worker_fees':unknown,'dispatched_worker_intents':sum((folder/label/'model-intent.json').exists() for label in ['first','scout']),'terminal_worker_receipts':len(workers),'worker_fee_values':fees,'terminal_parse_errors':parse_errors}
 print(json.dumps(out),flush=True);return out
rows=[];total=0
per_case_reserve=2*plan['maximum_observed_worker_usd'][plan['haiku_model']]
for start in range(0,len(plan['cases']),plan['case_concurrency']):
 if total+plan['case_concurrency']*per_case_reserve>plan['API_batch_guard_usd']:break
 with concurrent.futures.ThreadPoolExecutor(max_workers=plan['case_concurrency']) as pool:window=list(pool.map(run,plan['cases'][start:start+plan['case_concurrency']]))
 rows.extend(window);total+=sum(r['known_actual_SDK_usage_usd'] for r in window)
 if not all(r['accepted'] for r in window):break
state='finished' if len(rows)==len(plan['cases']) and all(r['accepted'] for r in rows) else 'stopped'
save(ROOT/'live-terminal.json',{'state':state,'rows':rows,'unclaimed_ids':[c['instance_id'] for c in plan['cases'][len(rows):]],'known_new_API_usage_usd':total,'unknown_worker_fees':sum(r['unknown_worker_fees'] for r in rows),'completed_unix':time.time(),'program_accounted':False,'model_retries':0,'no_new_repairs':True})
assert state=='finished'
