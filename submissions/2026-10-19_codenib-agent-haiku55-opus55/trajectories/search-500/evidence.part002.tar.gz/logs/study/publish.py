"""Export fixed500 metrics after source, scoring and actual fee reconciliation.

Public rows contain metrics and public task/source identities, never prompts,
source bodies, Gold, provider IDs or local paths. The older Max control retains
its failed-zero position and unknown fee; no complete cash-cost ratio is implied.
"""

import csv
import hashlib
import json
import math
from decimal import Decimal
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/researcher/SysEvol/CodeMiner")
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
LEVELS = ["file", "symbol", "line"]
METRICS = ["recall", "precision", "f1"]


def source_lines(prediction):
    return len({(name, line) for name, spans in prediction["traj_data"]["pred_spans"].items() for span in spans for line in range(span["start"], span["end"] + 1)})


def export(root, destination):
    plan = load(root / "protocol.json")
    analysis = load(root / "analysis.json")
    closure = load(root / "budget-reservation-closure.json")
    settled = load(root / "budget-settlement-verification.json")
    seal = load(root / "sealed-comparison.json")
    access = load(root / "annotation-access.json")
    post = load(root / "postprocess-terminal.json")
    assert plan["population"] == analysis["population"] == len(plan["cases"]) == 500
    assert analysis["protocol_sha256"] == sha(root / "protocol.json")
    assert post["state"] == "finished" and post["analysis_sha256"] == sha(root / "analysis.json")
    assert analysis["source_seal_sha256"] == sha(root / "sealed-comparison.json")
    assert seal["sealed_unix"] < access["opened_unix"]
    assert len(seal["worker_positions"]) == 1000 and all(w["accepted"] and not w["unknown_fee"] for w in seal["worker_positions"])
    assert closure["state"] == "closed" and settled["both_existing_state_views_reconciled"]
    assert settled["closure_sha256"] == sha(root / "budget-reservation-closure.json")
    assert closure["new_known_API_usage_decimal"] == analysis["known_new_API_usage_decimal"]
    assert analysis["unknown_worker_fees"] == 0 and len(analysis["actual_worker_usage"]) == 1000
    usage = {(r["instance_id"], r["worker"]): r for r in analysis["actual_worker_usage"]}
    cases = {r["instance_id"]: r for r in plan["cases"]}
    expected = {(key, worker) for key in cases for worker in ["first", "scout"]}
    assert len(usage) == 1000 and set(usage) == expected
    assert sum((Decimal(str(r["fee_usd"])) for r in usage.values()), Decimal(0)) == Decimal(analysis["known_new_API_usage_decimal"])
    audit_path = root / "non-source-git-metadata-audit.json"
    boundary_audit = {"status": "not_provided", "candidate_cases": None,
                      "predicted_non_source_lines": None,
                      "direct_line_recall_hits": None}
    if audit_path.exists():
        audit = load(audit_path)
        assert audit["analysis_sha256"] == sha(root / "analysis.json")
        assert audit["original_raw_metrics"] == analysis["candidate"]["macro"]
        assert not audit["originals_modified"] and not audit["score_replaced"]
        assert audit["Gold_Git_metadata_path_count"] == 0
        assert audit["Git_metadata_can_directly_add_line_recall_hits"] is False
        boundary_audit = {
            "status": "observed_git_metadata_outside_source_fingerprint",
            "audit_sha256": sha(audit_path),
            "candidate_cases": audit["case_count"],
            "predicted_non_source_lines": audit["predicted_git_metadata_lines"],
            "direct_line_recall_hits": 0,
            "covered_by_source_fingerprint": False,
            "original_predictions_and_metrics_preserved": True,
            "fresh_clone_entire_trace_replay_proven": False,
        }
    baseline_dir = Path(plan["baseline_analysis"]).parent
    baseline = load(Path(plan["baseline_analysis"]))
    assert sha(Path(plan["baseline_analysis"])) == plan["baseline_analysis_sha256"]
    control_plan = load(baseline_dir / "protocol.json")
    assert sha(baseline_dir / "protocol.json") == plan["baseline_protocol_sha256"]
    assert sha(baseline_dir / "confirmed-native-predictions.json") == control_plan["predictions_sha256"]
    control_preds = {p["instance_id"]: p for p in load(baseline_dir / "confirmed-native-predictions.json")["predictions"]}
    controls = {r["instance_id"]: r for r in baseline["cases"]}
    control_receipts = {r["instance_id"]: r for r in control_plan["receipts"]}
    assert len(control_preds) == len(controls) == len(control_receipts) == 500
    assert set(control_preds) == set(controls) == set(control_receipts) == set(cases)
    assert len(analysis["candidate"]["cases"]) == 500 and {r["instance_id"] for r in analysis["candidate"]["cases"]} == set(cases)
    rows = []
    for arm in ["haiku_scout_pair", "frozen_opus_native"]:
        for score in analysis["candidate"]["cases"]:
            key = score["instance_id"]
            case = cases[key]
            control = controls[key]
            receipt = control_receipts[key]
            is_candidate = arm == "haiku_scout_pair"
            fee = score["assembly"]["all_model_usage_usd"] if is_candidate else receipt["nominal_Max_sdk_usd"]
            metrics = score["metrics"] if is_candidate else {level: control["block" if level == "symbol" else level] for level in LEVELS}
            execution_valid = True if is_candidate else not receipt["original_failed_zero_source"]
            official_valid = score["valid"] if is_candidate else control["official_valid"]
            row = {"instance_id": key, "language": case["language"], "repo": case["repo"], "base_commit": case["base_commit"], "repo_alias_cluster": case["repo_alias_cluster"], "arm": arm, "execution_valid": execution_valid, "official_valid": official_valid, "valid": execution_valid and official_valid, "nominal_fee_usd": fee, "fee_known": fee is not None, "billing_route": "anthropic-api" if is_candidate else "historical-claude-subscription-nominal", "worker_count": 2 if is_candidate else 1}
            for level in LEVELS:
                for metric in METRICS:
                    value = metrics[level][metric]
                    assert type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1
                    row[level + "_" + metric] = value
            assembly = score["assembly"] if is_candidate else None
            row.update(unique_observed_source_lines=assembly["unique_observed_source_lines"] if is_candidate else source_lines(control_preds[key]), summed_worker_unique_source_lines=assembly["summed_worker_unique_source_lines"] if is_candidate else source_lines(control_preds[key]), repeated_source_lines_across_workers=assembly["repeated_source_lines_across_workers"] if is_candidate else 0, SDK_worker_loop_seconds_sum=sum(usage[key, w]["SDK_loop_seconds"] for w in ["first", "scout"]) if is_candidate else None, main_input_reconciled_workers=sum(usage[key, w]["main_input_status"] == "reconciled" for w in ["first", "scout"]) if is_candidate else None)
            if not execution_valid:
                assert all(row[level + "_" + metric] == 0 for level in LEVELS for metric in METRICS)
                assert row["unique_observed_source_lines"] == 0
            rows.append(row)
    assert len(rows) == 1000
    destination.mkdir(parents=True, exist_ok=True)
    csv_path = destination / "contextbench_search_pair_verified_500.csv"
    with csv_path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    reread = list(csv.DictReader(csv_path.open()))
    assert len(reread) == 1000
    for arm in ["haiku_scout_pair", "frozen_opus_native"]:
        selected = [r for r in reread if r["arm"] == arm]
        assert len(selected) == 500
        target = analysis["candidate"]["macro"] if arm == "haiku_scout_pair" else analysis["baseline"]["macro"]
        for level in LEVELS:
            for metric in METRICS:
                assert math.isclose(mean(float(r[level + "_" + metric]) for r in selected), target[level][metric], abs_tol=1e-12)
        known_total = sum(float(r["nominal_fee_usd"]) for r in selected if r["fee_known"] == "True")
        expected_total = float(analysis["known_new_API_usage_decimal"]) if arm == "haiku_scout_pair" else analysis["baseline"]["known_Max_nominal_fee_sum_usd"]
        assert math.isclose(known_total, expected_total, abs_tol=1e-8)
        unknown_ids = {r["instance_id"] for r in selected if r["fee_known"] == "False"}
        assert unknown_ids == (set() if arm == "haiku_scout_pair" else set(analysis["baseline"]["unknown_fee_cases"]))
    summary = {"scope": plan["scope"], "population": 500, "runtime_commit": plan["commit"], "protocol_sha256": sha(root / "protocol.json"), "analysis_sha256": sha(root / "analysis.json"), "source_seal_sha256": sha(root / "sealed-comparison.json"), "annotation_access_sha256": sha(root / "annotation-access.json"), "actual_worker_sessions": 1000, "candidate_macro": analysis["candidate"]["macro"], "candidate_official_valid_cases": analysis["candidate"]["valid"], "frozen_native500_macro": analysis["baseline"]["macro"], "baseline_original_failed_zero_positions": sum(r["original_failed_zero_source"] for r in control_receipts.values()), "baseline_known_Max_nominal_fee_sum_usd": analysis["baseline"]["known_Max_nominal_fee_sum_usd"], "baseline_unknown_fee_cases": analysis["baseline"]["unknown_fee_cases"], "baseline_fees_complete": not analysis["baseline"]["unknown_fee_cases"], "baseline_prior122_annotation_timing_disclosed": True, "paired_differences_vs_frozen_native500": analysis["paired_differences_vs_frozen_native500"], "bootstrap": analysis["bootstrap"], "known_new_API_usage_decimal": analysis["known_new_API_usage_decimal"], "known_program_API_usage_after_usd": closure["known_program_API_usage_usd"], "remaining_API_allowance_usd": closure["remaining_API_allowance_usd"], "cash_invoice_or_credit_balance_reconciled": False, "fresh_independent_sample": False, "matched_model_billing_or_cache_ablation": False, "metadata_alone_causal_gain_established": False, "Pass_at_1_evaluated": False, "official_submission_ready": False, "source_bodies_issues_Gold_provider_IDs_local_paths_exported": False, "repair_calls": 0, "Jev_requests": 0, "csv_sha256": sha(csv_path)}
    summary.update(
        cost_scope="context_search_only",
        downstream_repair_and_native_grading_included=False,
        complete_resolution_cost_evaluated=False,
        compute_cost_included=False,
        source_boundary_audit=boundary_audit,
        raw_publication_ready=False,
    )
    json_path = destination / "contextbench_search_pair_verified_summary.json"
    with json_path.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return {"public_rows": 1000, "csv": str(csv_path), "csv_sha256": sha(csv_path), "summary": str(json_path), "summary_sha256": sha(json_path), "all_fixed500_metrics_and_known_unknown_fees_verified": True, "new_model_calls": 0}


if __name__ == "__main__":
    result = export(ROOT, REPO / "docs/assets")
    with (ROOT / "public-export-verification.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))
