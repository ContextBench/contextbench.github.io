"""Seal every fixed position, then reopen only the known canonical500 labels.

Failed/unclaimed positions and original raw bytes remain explicit. Source or fee
integrity failures seal evidence but block Gold. This is a descriptive comparison
to a frozen older native500 control, not a new independent or matched-model trial.
"""

import hashlib
import json
import math
import os
import subprocess
import sys
import time
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from statistics import mean

import numpy as np

ROOT = Path(__file__).resolve().parent
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
plan = load(ROOT / "protocol.json")
sys.path.insert(0, plan["runtime"])
from codenib.dataset.contextbench import ContextBenchCase
from scripts import benchmark_context_agent as native
from scripts.contextbench_evidence_review import confirmed_history
from scripts.contextbench_search_pair import assemble_workers
from scripts.contextbench_usage import summarize_response_inputs


def save(name, value):
    with (ROOT / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def known(fee):
    return type(fee) in (float, int) and math.isfinite(fee) and fee >= 0


def frozen():
    for name, field in [("report.py", "report_driver_sha256"), ("run.py", "driver_sha256"), ("case.py", "case_driver_sha256"), ("postprocess.py", "postprocess_driver_sha256"), ("design.json", "design_sha256"), ("selection.json", "selection_sha256")]:
        assert sha(ROOT / name) == plan[field], name
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=plan["runtime"], text=True).strip() == plan["commit"]
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=plan["runtime"], text=True).strip()
    for name, digest in plan["implementation"].items():
        assert sha(Path(plan["runtime"]) / name) == digest, name


def freeze():
    assert not (ROOT / "annotation-access.json").exists()
    integrity = []
    try:
        frozen()
    except (AssertionError, OSError, ValueError) as error:
        integrity.append(type(error).__name__)
    terminal = load(ROOT / "live-terminal.json")
    receipts, positions, predictions = [], [], []
    for case in plan["cases"]:
        key = case["instance_id"]
        folder = ROOT / "live" / key
        errors = []

        def optional_json(path):
            if not path.exists():
                return {}
            try:
                value = load(path)
                assert isinstance(value, dict)
                return value
            except (OSError, ValueError, AssertionError) as error:
                errors.append({"file": path.name, "error": type(error).__name__})
                return {}

        end = optional_json(folder / "case-terminal.json")
        workers = end.get("workers", {})
        files = {}
        validated = []
        for label in plan["worker_order"]:
            path = folder / label / "trajectory.json"
            raw = optional_json(path)
            intent = folder / label / "model-intent.json"
            for evidence in [path, intent, folder / label / "prediction.json"]:
                if evidence.exists():
                    files[str(evidence)] = sha(evidence)
            worker = workers.get(label)
            accepted = False
            if worker and worker.get("accepted"):
                try:
                    assert not integrity
                    assert sha(Path(case["input"])) == case["input_sha256"]
                    assert worker["commit"] == case["base_commit"]
                    assert worker["source_fingerprint"] == plan["source_fingerprints"][key]
                    assert Path(worker["raw"]).resolve() == path.resolve()
                    assert sha(path) == worker["raw_sha256"] and raw["accepted"] is True
                    assert raw["configured_model"] == plan["haiku_model"]
                    assert raw["source_context"]["verified"] is True
                    assert raw["source_context"]["source_fingerprint"] == worker["source_fingerprint"]
                    assert known(raw.get("sdk_reported_cost_usd"))
                    assert raw["sdk_reported_cost_usd"] == worker["all_model_usage_usd"]
                    assert worker["prediction"] == native.contextbench_prediction(instance_id=key, messages=confirmed_history(raw["messages"]), repo_path=load(Path(case["input"]))["repo"])
                    assert worker["prediction"] == load(folder / label / "prediction.json")
                    accepted = True
                    validated.append(worker)
                except (AssertionError, OSError, ValueError, KeyError, TypeError) as error:
                    errors.append({"worker": label, "error": type(error).__name__})
            fee = raw.get("sdk_reported_cost_usd")
            positions.append({
                "instance_id": key, "worker": label, "dispatched": intent.exists(),
                "accepted": accepted, "fee_usd": fee if known(fee) else None,
                "unknown_fee": intent.exists() and not known(fee),
                "raw_sha256": sha(path) if path.exists() else None,
            })
        valid = len(validated) == len(plan["worker_order"]) and not errors and not integrity
        pred = {"instance_id": key, "traj_data": {"pred_steps": [], "pred_files": [], "pred_spans": {}}, "model_patch": ""}
        assembly = None
        if valid:
            try:
                pred, assembly = assemble_workers(key, validated)
                assert pred == load(folder / "haiku_scout_pair-prediction.json")
            except (AssertionError, OSError, ValueError, KeyError, TypeError) as error:
                errors.append({"assembly_error": type(error).__name__})
                valid = False
                pred = {"instance_id": key, "traj_data": {"pred_steps": [], "pred_files": [], "pred_spans": {}}, "model_patch": ""}
                assembly = None
        predictions.append(pred)
        receipts.append({"instance_id": key, "arm": "haiku_scout_pair", "accepted": valid, "assembly": assembly, "raw_files_sha256": files, "integrity_errors": errors})
    save("sealed-comparison.json", {
        "protocol_sha256": sha(ROOT / "protocol.json"),
        "live_terminal_sha256": sha(ROOT / "live-terminal.json"),
        "ids": [c["instance_id"] for c in plan["cases"]],
        "arms": {"haiku_scout_pair": predictions}, "receipts": receipts,
        "worker_positions": positions, "protocol_integrity_errors": integrity,
        "sealed_unix": time.time(), "new_annotation_reads_at_freeze": 0,
        "source_bodies_added_by_assembler": 0,
        "failed_unclaimed_positions_retained_as_zero": True,
    })
    print(json.dumps({"sealed_configuration_positions": len(receipts), "sealed_worker_positions": len(positions), "Gold_reads": 0}))


def evaluate():
    frozen()
    seal = load(ROOT / "sealed-comparison.json")
    from postprocess import source_gate
    assert source_gate(plan, load(ROOT / "live-terminal.json"), seal)
    assert seal["protocol_sha256"] == sha(ROOT / "protocol.json")
    assert seal["live_terminal_sha256"] == sha(ROOT / "live-terminal.json")
    assert len(seal["ids"]) == len(plan["cases"]) == plan["population"]
    assert not seal["protocol_integrity_errors"] and all(r["accepted"] for r in seal["receipts"])
    assert all(w["dispatched"] and w["accepted"] and not w["unknown_fee"] for w in seal["worker_positions"])
    for receipt in seal["receipts"]:
        for name, digest in receipt["raw_files_sha256"].items():
            assert sha(Path(name)) == digest
    assert sha(Path(plan["dataset"])) == plan["dataset_sha256"]
    save("annotation-access.json", {"scope": "Reopen ONLY the SAME already-exposed canonical500 Gold after all new source outcomes seal. Not a new independent annotation population. No future/unselected labels or reference patches/tests.", "selected_ids": seal["ids"], "columns": ["instance_id", "gold_context"], "opened_unix": time.time(), "sealed_sha256": sha(ROOT / "sealed-comparison.json"), "population_already_exposed": True})
    import pyarrow.dataset as ds
    projected = ds.dataset(plan["dataset"], format="parquet").to_table(columns=["instance_id", "gold_context"], filter=ds.field("instance_id").isin(seal["ids"])).to_pylist()
    gold = {row["instance_id"]: row["gold_context"] for row in projected}
    assert len(gold) == len(projected) == plan["population"] and set(gold) == set(seal["ids"])
    for name, digest in plan["evaluator_sources"].items():
        assert sha(Path(plan["evaluator_upstream"]) / name) == digest
    items = []
    for case, pred in zip(plan["cases"], seal["arms"]["haiku_scout_pair"], strict=True):
        key = case["instance_id"]
        assert key == pred["instance_id"]
        mapping = {k: case[k] for k in ["instance_id", "original_inst_id", "repo", "repo_url", "base_commit", "language"]}
        mapping.update(problem_statement="", gold_context=gold[key])
        parsed = ContextBenchCase.from_mapping(mapping)
        items.append({"repo_path": load(Path(case["input"]))["repo"], "gold": {"inst_id": key, "original_inst_id": case["original_inst_id"], "repo_url": case["repo_url"], "commit": case["base_commit"], "gold_ctx": list(parsed.gold_context)}, "prediction": pred})
    save("haiku_scout_pair-evaluation-input.json", items)
    command = native.contextbench_evaluator_command(Path(plan["evaluator_upstream"]), plan["evaluator_python"])
    with (ROOT / "haiku_scout_pair-evaluation.log").open("x") as stream:
        result = subprocess.run([*command, "--input", str(ROOT / "haiku_scout_pair-evaluation-input.json"), "--output", str(ROOT / "haiku_scout_pair-metrics.json")], stdout=stream, stderr=subprocess.STDOUT, timeout=7200)
    assert result.returncode in [0, 1]
    official = load(ROOT / "haiku_scout_pair-metrics.json")
    by = {row["instance_id"]: row for row in official["cases"]}
    assert len(by) == len(official["cases"]) == plan["population"] and set(by) == set(seal["ids"])
    rows = []
    for case, receipt in zip(plan["cases"], seal["receipts"], strict=True):
        key = case["instance_id"]
        score = by[key]
        valid = "error" not in score and "final" in score
        metrics = {}
        for level in ["file", "symbol", "line"]:
            r = score["final"][level]["coverage"] if valid else 0
            p = score["final"][level]["precision"] if valid else 0
            metrics[level] = {"recall": r, "precision": p, "f1": 2 * r * p / (r + p) if r + p else 0}
        rows.append({"instance_id": key, "language": case["language"], "repo_alias_cluster": case["repo_alias_cluster"], "valid": valid, "metrics": metrics, "assembly": receipt["assembly"], "error": score.get("error")})
    macro = {level: {metric: mean(r["metrics"][level][metric] for r in rows) for metric in ["recall", "precision", "f1"]} for level in ["file", "symbol", "line"]}
    actual, usage = Decimal(0), []
    for case in plan["cases"]:
        for label in plan["worker_order"]:
            raw = load(ROOT / "live" / case["instance_id"] / label / "trajectory.json")
            fee = raw["sdk_reported_cost_usd"]
            assert known(fee) and math.isclose(sum(v["costUSD"] for v in raw["sdk_result"]["model_usage"].values()), fee, abs_tol=1e-10)
            actual += Decimal(str(fee))
            item = {"instance_id": case["instance_id"], "worker": label, "fee_usd": fee, "SDK_loop_seconds": raw["sdk_result"].get("duration_ms", 0) / 1000, "measured_worker_seconds": raw.get("elapsed_seconds")}
            try:
                item["main_inputs"] = summarize_response_inputs(raw, model=raw["configured_model"])
                item["main_input_status"] = "reconciled"
            except ValueError:
                item["main_inputs"] = None
                item["main_input_status"] = "incomplete"
            usage.append(item)
    assert len(usage) == 2 * plan["population"]
    assert math.isclose(float(actual), sum(r["assembly"]["all_model_usage_usd"] for r in rows), abs_tol=1e-9)
    baseline_path = Path(plan["baseline_analysis"])
    assert sha(baseline_path) == plan["baseline_analysis_sha256"]
    baseline = load(baseline_path)
    old = {r["instance_id"]: r for r in baseline["cases"]}
    assert len(old) == len(baseline["cases"]) == plan["population"] and set(old) == set(seal["ids"])
    old_macro = {}
    for level, prior in [("file", "file"), ("symbol", "block"), ("line", "line")]:
        old_macro[level] = {metric: mean(old[key][prior][metric] for key in seal["ids"]) for metric in ["recall", "precision", "f1"]}
        for metric in old_macro[level]:
            assert math.isclose(old_macro[level][metric], baseline["failure_accounted_snapshot_macro"][prior][metric], abs_tol=1e-12)
    clusters = defaultdict(list)
    for index, case in enumerate(plan["cases"]):
        clusters[case["repo_alias_cluster"]].append(index)
    groups = list(clusters.values())
    rng = np.random.default_rng(20261020)
    samples = [np.concatenate([groups[i] for i in rng.integers(0, len(groups), len(groups))]) for _ in range(10000)]
    paired = {}
    for metric in ["recall", "precision", "f1"]:
        differences = np.array([row["metrics"]["line"][metric] - old[row["instance_id"]]["line"][metric] for row in rows])
        paired[metric] = {"difference": float(differences.mean()), "paired_repo_alias_percentile95": np.percentile([differences[index].mean() for index in samples], [2.5, 97.5]).tolist()}
    save("analysis.json", {"scope": plan["scope"], "protocol_sha256": sha(ROOT / "protocol.json"), "source_seal_sha256": sha(ROOT / "sealed-comparison.json"), "population": plan["population"], "candidate": {"name": "haiku_scout_pair", "valid": sum(r["valid"] for r in rows), "macro": macro, "cases": rows}, "baseline": {"scope": "Frozen older native500 control; original empty-source zero, unknown fee and122-case annotation timing preserved. Not a fresh matched-model/billing comparison.", "analysis_sha256": sha(baseline_path), "macro": old_macro, "known_Max_nominal_fee_sum_usd": baseline["known_baseline_Max_nominal_sdk_usd"], "unknown_fee_cases": baseline["selected_native_unknown_usage_cases"]}, "paired_differences_vs_frozen_native500": paired, "bootstrap": {"clusters": len(groups), "resamples": 10000, "seed": 20261020, "interval": "percentile95unadjusted", "independent_generalization_claim": False}, "known_new_API_usage_decimal": str(actual), "unknown_worker_fees": 0, "actual_worker_usage": usage, "all_actual_sessions_counted_once": True, "fresh_independent_sample": False, "metadata_alone_causal_gain_established": False, "native_issue_resolution_evaluated": False, "official_submission_ready": False, "repair_calls": 0, "Jev_requests": 0})
    print(json.dumps({"candidate_macro": macro, "frozen_native500_macro": old_macro, "paired_differences": paired, "new_nominal_API_usage_decimal": str(actual)}))


if __name__ == "__main__":
    {"freeze": freeze, "evaluate": evaluate}[sys.argv[1]]()
