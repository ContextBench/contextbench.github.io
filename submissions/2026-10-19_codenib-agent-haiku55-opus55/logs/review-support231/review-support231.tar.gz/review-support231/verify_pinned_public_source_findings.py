"""Portably bind declared Git-blob findings to exact anonymous public files.

An exclusive output directory owns decoder/Git children; root owns interrupted
recovery. Only validated object storage enters disposable bare repositories.
Public file bodies stay in memory and never enter reports. Classification uses
complete-byte equality, not a filename, header, or model judgment. Originals,
candidate outputs, scan findings and financial ledgers remain read-only.
"""

import argparse
import collections
import concurrent.futures
import importlib.util
import io
import json
import os
import re
import sys
import subprocess
import tarfile
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "authenticated_multi_root_source_reader",
    ROOT / "portable_review_git.py",
)
reader = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = reader
spec.loader.exec_module(reader)
base = reader.base
load = lambda path: json.loads(path.read_text())


def exact_public_source(actual, public):
    if actual != public:
        raise ValueError("Complete public-source bytes differ")


def public_file(item):
    url = item["url"]
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/octet-stream",
            "User-Agent": "codenib-contextbench-source-audit",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            destination = urllib.parse.urlparse(response.geturl())
            assert destination.scheme == "https"
            assert destination.hostname == "raw.githubusercontent.com"
            assert response.status == 200
            data = response.read(16 * 1024**2 + 1)
            assert len(data) <= 16 * 1024**2, "Public source exceeds explicit read cap"
        return data, {**item, "HTTP_status": 200, "bytes": len(data),
                      "authorization_header_supplied": False}
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as error:
        return None, {**item, "error_class": type(error).__name__,
                      "HTTP_status": getattr(error, "code", None),
                      "authorization_header_supplied": False}


def main(args):
    review, parts, out = args.review, args.parts, args.output
    out.mkdir(exist_ok=False)
    findings_path = review / "findings.json"
    findings = load(findings_path)["patterns"]
    proof = load(review / "verification.json")
    assert findings and len(findings) == proof["pattern_findings"]
    assert proof["sensitive_named_fields"] == 0
    assert all(row["scope"] == "decompressed_git_object" and
               row["object_type"] == "blob" and
               row["pattern"] == "private_key_header" and
               row["git_root"] == ".git" for row in findings)
    assert len({(x["member"], x["git_root"], x["object_id"], x["offset"])
                for x in findings}) == len(findings)
    assert proof["all_decompressed_object_ids_recomputed"]
    records_path = review / "Git-object-review.json"
    git_records = {(row["archive"], row["git_root"]): row
                   for row in load(records_path)}
    cases = {row["instance_id"]: row for row in load(args.queue)["queue"]}
    index_path = parts / "artifact-index.json"
    index = load(index_path)
    assert base.file_sha(index_path) == proof["input_part_index_sha256"]
    stream_path = review / "verified-input.tar.zst"
    assert base.file_sha(stream_path) == index["compressed_stream_sha256"]
    originals = {row["name"]: row for row in index["members"]}
    by_member = collections.defaultdict(list)
    representatives = {}
    for finding in findings:
        member = finding["member"]
        identity = member.split("/source-admissions/")[1].split("/")[0]
        case = cases[identity]
        record = git_records[(member, finding["git_root"])]
        assert record["head_commit"] == case["base_commit"]
        assert re.fullmatch(r"[0-9a-f]{40}", case["base_commit"])
        assert re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", case["native_repo"])
        assert finding["paths_at_seed_HEAD"]
        path = finding["paths_at_seed_HEAD"][0]
        relative = PurePosixPath(path)
        assert not relative.is_absolute() and ".." not in relative.parts
        assert "\\" not in path and "\x00" not in path
        representatives.setdefault(finding["object_id"], {
            "Git_blob_ID": finding["object_id"],
            "public_repository": case["native_repo"],
            "public_commit": case["base_commit"],
            "public_source_path": path,
            "url": "https://raw.githubusercontent.com/" + case["native_repo"] +
                   "/" + case["base_commit"] + "/" + urllib.parse.quote(path, safe="/"),
        })
        by_member[member].append(finding)
    base.save(out / "intent.json", {
        "pid": os.getpid(), "driver_sha256": base.file_sha(Path(__file__)),
        "review_verification_sha256": base.file_sha(review / "verification.json"),
        "findings_sha256": base.file_sha(findings_path),
        "Git_review_sha256": base.file_sha(records_path),
        "actual_part_index_sha256": base.file_sha(index_path),
        "queue_metadata_sha256": base.file_sha(args.queue),
        "portable_git_helper_sha256": base.file_sha(Path(reader.__file__)),
        "original_review_driver_sha256": proof["driver_sha256"],
        "public_source_requests": len(representatives),
        "matched_values_never_printed_or_stored_in_reports": True,
        "model_calls": 0, "native_tests": 0, "financial_mutations": 0,
    })
    public, provenance = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for data, metadata in pool.map(public_file, representatives.values()):
            provenance.append(metadata)
            if data is not None:
                public[metadata["Git_blob_ID"]] = data
    base.save(out / "public-source-provenance.json", provenance)
    assert len(public) == len(representatives), "Anonymous public-source retrieval incomplete"
    print(json.dumps({"anonymous_public_source_files_fetched": len(public),
                      "body_values_reported": False, "model_calls": 0}), flush=True)

    pattern = base.prior.PATTERNS["private_key_header"]
    classified, seen = [], set()
    boundary_checked = False
    with (out / "decompression.log").open("x") as errors:
        child = subprocess.Popen(
            ["zstd", "-d", "--memory=1024MB", "-c", str(stream_path)],
            stdout=subprocess.PIPE, stderr=errors,
        )
        try:
            with tarfile.open(fileobj=child.stdout, mode="r|", bufsize=1024**2) as archive:
                for member in archive:
                    if member.name not in by_member:
                        continue
                    assert member.isfile() and member.name not in seen
                    data = archive.extractfile(member).read()
                    expected = originals[member.name]
                    assert len(data) == expected["publication_bytes"]
                    assert base.sha(data) == expected["publication_sha256"]
                    groups = reader.git_groups(data)
                    items = by_member[member.name]
                    with tempfile.TemporaryDirectory(prefix="public-source-", dir=out) as temporary:
                        bare = Path(temporary)
                        base.bare_directory(bare)
                        for name, content in groups[".git"].items():
                            if not base.OBJECT_NAME.fullmatch(name):
                                continue
                            target = bare / name
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.write_bytes(content)

                        def git(*args):
                            return subprocess.check_output(
                                base.git_command(bare, *args), env=base.ENV,
                                stderr=subprocess.PIPE, timeout=60,
                            )

                        blobs = {}
                        commit = git_records[(member.name, ".git")]["head_commit"]
                        for finding in items:
                            oid = finding["object_id"]
                            if oid not in blobs:
                                blobs[oid] = git("cat-file", "blob", oid)
                                exact_public_source(blobs[oid], public[oid])
                                observed = {match.start() for match in pattern.finditer(blobs[oid])}
                                expected_offsets = {row["offset"] for row in items
                                                    if row["object_id"] == oid}
                                assert observed == expected_offsets
                            for path in finding["paths_at_seed_HEAD"]:
                                entry = git("ls-tree", "-z", commit, "--", path)
                                header, recorded_path = entry.rstrip(b"\0").split(b"\t", 1)
                                mode, kind, tree_oid = header.split()
                                assert mode in {b"100644", b"100755"} and kind == b"blob"
                                assert tree_oid.decode() == oid and recorded_path.decode() == path
                            if not boundary_checked:
                                changed = bytearray(blobs[oid])
                                position = pattern.search(changed).end() + 1
                                assert position < len(changed)
                                changed[position] ^= 1
                                assert [x.start() for x in pattern.finditer(changed)] == [
                                    x.start() for x in pattern.finditer(blobs[oid])]
                                try:
                                    exact_public_source(bytes(changed), public[oid])
                                except ValueError:
                                    pass
                                else:
                                    raise AssertionError("Altered body was accepted from header/path alone")
                                boundary_checked = True
                            classified.append({
                                "finding": finding,
                                "classification": "byte-identical-pinned-public-upstream-source",
                                "source_commit": commit,
                                "all_recorded_seed_paths_bound_to_original_blob": True,
                                "complete_anonymous_public_file_bytes_equal": True,
                                "public_source": representatives[oid],
                                "archived_config_hooks_alternates_or_remote_commands_used": False,
                            })
                    seen.add(member.name)
            while child.stdout.read(1024**2):
                pass
            child.stdout.close()
            assert child.wait(timeout=60) == 0
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=30)
    assert seen == set(by_member) and len(classified) == len(findings) and boundary_checked
    base.save(out / "classifications.json", classified)
    result = {
        "original_pattern_findings_retained": len(findings),
        "occurrences_classified_as_exact_public_source": len(classified),
        "unique_public_Git_blobs_verified": len(public),
        "anonymous_public_repository_count": len({x["public_repository"] for x in provenance}),
        "all_recorded_seed_commits_and_paths_verified": True,
        "complete_file_bytes_compared_not_header_or_path_only": True,
        "same_header_and_path_with_changed_body_rejected": boundary_checked,
        "unclassified_findings": 0,
        "findings_sha256": base.file_sha(findings_path),
        "actual_part_index_sha256": base.file_sha(index_path),
        "public_provenance_sha256": base.file_sha(out / "public-source-provenance.json"),
        "classifications_sha256": base.file_sha(out / "classifications.json"),
        "driver_sha256": base.file_sha(Path(__file__)),
        "portable_git_helper_sha256": base.file_sha(Path(reader.__file__)),
        "queue_metadata_sha256": base.file_sha(args.queue),
        "original_scan_archives_and_model_artifacts_modified": False,
        "matched_values_in_reports": False,
        "declared_pattern_context_resolved_not_arbitrary_secret_review": True,
        "public_release_approved": False, "formal_full500_submission_ready": False,
        "model_calls": 0, "native_tests": 0, "financial_mutations": 0,
    }
    base.save(out / "verification.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--queue", type=Path, required=True)
    parser.add_argument("--review", type=Path, required=True)
    parser.add_argument("--parts", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
