Review support for the closed231 private payloads

This supplement contains post-archive review metadata and verification tools.
It is not a full500 score, a replacement for raw interactions, publication
approval, an assertion that arbitrary secrets are absent, or a native-test rerun.
Keep the complete repair/search archives and their own artifact indices.

1. Verify this actual bounded support part without extracting it:
   python verify_support_bundle.py --parts /path/to/support-parts
   This uses only Python standard-library modules and makes no network/model call.
   It hashes actual part/member bytes and checks the recorded proof links.

2. Extract the support TAR into a fresh directory:
   gzip -dc /path/to/support-parts/review-support231.tar.gz | tar -xf - -C /fresh/directory
   The extracted review-support231 directory contains the portable tools below.

3. Repeat Pro source classification using Python3.10+, system git and zstd.
   Set CB_REVIEW to the extracted review-support231 directory and CB_RAW to
   the directory containing the original complete raw archive folders.

CB_REVIEW=/path/to/extracted/review-support231
CB_RAW=/path/to/raw-archives
cat "$CB_RAW/completed-Pro54-publication-preview/parts"/repair-increment-publication-preview.tar.zst.part* > "$CB_REVIEW/Pro54-pattern-review/verified-input.tar.zst"
python "$CB_REVIEW/verify_pinned_public_source_findings.py" \
  --queue "$CB_REVIEW/queue-metadata.json" \
  --review "$CB_REVIEW/Pro54-pattern-review" \
  --parts "$CB_RAW/completed-Pro54-publication-preview/parts" \
  --output /path/to/fresh-source-verification

This rehashes the actual combined stream against its original index, reads only
validated Git object storage, binds every finding to its exact seed commit/path,
and compares complete blob bytes to53 anonymously fetched pinned public files.
It retains all216 findings and rejects changed bodies with unchanged headers.
The copied-input test reproduced all216 classifications without reading original
checkout/experiment/credential files through Python. Only explicit git/zstd child
programs are allowed in that test; public upstream HTTP is intentionally allowed.
Those guards are not an OS sandbox. No model API credentials or calls are needed.

4. Reproduce231 selections and fee receipts from the actual raw benchmark parts
   using replay_publication_repair_receipts.py. See231-relocated-replay/README.private.txt
   for the complete command: four repair-part folders (58,64,55,Pro54), the search
   packaged parts and their session digest links, --cases231 and the exact member
   canonical500-candidate-repair/completed231-raw-index/repair-index.jsonl.
   Run in a fresh output directory with the installed frozen runtime dependencies.

The original replay authenticated42 raw parts and43,510 member occurrences,
loaded1,703 bundled runtime files, and reproduced all231 original selections,
first-patch/native bindings and2,521 unique sessions. It retained188 resolved and
43 unresolved outcomes and$141.76314628 allocated search-plus-repair usage.
This is receipt portability with installed dependencies, not a clean dependency
installation, fresh-clone footprint replay, native execution or official rescoring.

Metadata projection contains all500 public task IDs/source/base-commit/repository
fields only. It contains no issues, reference patches, prompts or workstation
source paths. Original full raw archives remain the source of benchmark records.
