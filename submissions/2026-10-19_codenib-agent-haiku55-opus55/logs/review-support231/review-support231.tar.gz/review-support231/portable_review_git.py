"""Standard-library Git storage reader for portable public-source verification.

Validate every root before Git execution. Only object storage enters a fresh
bare repository: archived config, hooks, alternates and replacements never run.
The caller owns temporary directories and subprocess recovery.
"""
import hashlib
import io
import json
import re
import sys
import tarfile
from pathlib import Path, PurePosixPath
from types import SimpleNamespace

OBJECT_NAME = re.compile(r"objects/(?:[0-9a-f]{2}/[0-9a-f]{38}|pack/pack-[0-9a-f]{40}\.(?:pack|idx|rev|bitmap))\Z")
ENV = {
    "PATH": "/usr/bin:/bin", "LC_ALL": "C", "GIT_CONFIG_NOSYSTEM": "1",
    "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_SYSTEM": "/dev/null",
    "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0", "GIT_NO_REPLACE_OBJECTS": "1",
}
prior = SimpleNamespace(PATTERNS={
    "private_key_header": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
})
base = sys.modules[__name__]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            value.update(block)
    return value.hexdigest()


def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


def git_command(directory, *args):
    return ["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "-c", "core.fsmonitor=false",
            "-c", "core.attributesFile=/dev/null", "-c", "protocol.allow=never",
            "--git-dir=" + str(directory), *args]


def bare_directory(directory):
    (directory / "objects/pack").mkdir(parents=True)
    (directory / "refs/heads").mkdir(parents=True)
    (directory / "config").write_text("[core]\nrepositoryformatversion = 0\nbare = true\n")
    (directory / "HEAD").write_text("ref: refs/heads/main\n")


def git_groups(data):
    groups, seen = {}, set()
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and ".." not in name.parts
            assert name.as_posix() not in seen
            seen.add(name.as_posix())
            assert member.isfile() or member.isdir()
            if member.isdir():
                continue
            assert name.parts.count(".git") == 1
            position = name.parts.index(".git")
            assert position + 1 < len(name.parts)
            root = PurePosixPath(*name.parts[:position + 1]).as_posix()
            relative = PurePosixPath(*name.parts[position + 1:]).as_posix()
            if relative.startswith("objects/") and not OBJECT_NAME.fullmatch(relative):
                raise ValueError("Unsupported Git object storage; no alternates allowed")
            groups.setdefault(root, {})[relative] = archive.extractfile(member).read()
    assert groups and ".git" in groups
    for files in groups.values():
        assert "HEAD" in files and any(name.startswith("objects/") for name in files)
    return groups
