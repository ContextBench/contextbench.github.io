"""Replay published repair inputs, selections and fees in a relocated directory.

Only declared public artifact indices, their actual bounded parts and public
session-digest links are inputs. The worker imports the bundled frozen runtime,
not the original checkout. A Python audit hook restricts opens to the relocated
data/runtime and installed dependencies, and denies networking/child processes.
This verifies receipt/selection/fee portability, not fresh-clone source footprints,
native test reproduction, new official scores or publication approval.

Exclusive output creation owns decoder/worker children; root owns interrupted
recovery. Original files, paid owners and financial ledgers remain read-only.
"""

import argparse
import collections
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tarfile
from decimal import Decimal
from pathlib import Path, PurePosixPath


def load(path):
    return json.loads(path.read_text())


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            value.update(block)
    return value.hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def safe_relative(name):
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or not path.parts:
        raise ValueError("Unsafe archived member name")
    return Path(*path.parts)


def needed_repair(name, closed_index):
    path = PurePosixPath(name)
    return (
        name == closed_index
        or name == "publication-support/repair-runtime-source.tar.gz"
        or path.name in {
            "solver.json", "model-observations.json", "search-pair-handoff.json",
            "whole-run-usage.json", "selected-context.json", "selection-receipt.json",
            "resolution.json", "predictions.json", "whole-run-result.json",
            "redaction-manifest.json", "session-digest-linkage.json",
        }
        or path.name == "config.json" and path.parent.name in {"solver", "native", "native-recovery"}
    )


def decode_parts(folder, destination, select, *, zstd_work):
    index = load(folder / "artifact-index.json")
    expected = {row["name"]: row for row in index["members"]}
    assert len(expected) == len(index["members"])
    seen, selected = set(), set()
    whole = hashlib.sha256()
    paths = []
    for item in index["parts"]:
        assert Path(item["path"]).name == item["path"]
        path = folder / item["path"]
        assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"]
        paths.append(path)
    is_zstd = "compressed_stream_sha256" in index
    if is_zstd:
        with zstd_work.open("xb") as target:
            for path in paths:
                with path.open("rb") as source:
                    for block in iter(lambda: source.read(1024**2), b""):
                        target.write(block)
                        whole.update(block)
        assert whole.hexdigest() == index["compressed_stream_sha256"]

    def extract(archive):
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in seen
            relative = safe_relative(member.name)
            item = expected[member.name]
            size = item.get("publication_bytes", item.get("bytes"))
            checksum = item.get("publication_sha256", item.get("sha256"))
            assert member.size == size
            keep = select(member.name)
            target_path = destination / relative
            target, count, value = None, 0, hashlib.sha256()
            if keep:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                if not target_path.exists():
                    target = target_path.open("xb")
            try:
                with archive.extractfile(member) as source:
                    for block in iter(lambda: source.read(1024**2), b""):
                        count += len(block)
                        value.update(block)
                        if target:
                            target.write(block)
            finally:
                if target:
                    target.close()
            assert count == size and value.hexdigest() == checksum
            if keep:
                assert target_path.stat().st_size == size and sha(target_path) == checksum
                selected.add(member.name)
            seen.add(member.name)

    if is_zstd:
        with zstd_work.with_suffix(".decoder.log").open("x") as log:
            child = subprocess.Popen(["zstd", "-d", "--memory=1024MB", "-c", str(zstd_work)], stdout=subprocess.PIPE, stderr=log)
            try:
                with tarfile.open(fileobj=child.stdout, mode="r|", bufsize=1024**2) as archive:
                    extract(archive)
                while child.stdout.read(1024**2):
                    pass
                child.stdout.close()
                assert child.wait(timeout=60) == 0
            finally:
                if child.poll() is None:
                    child.kill()
                    child.wait(timeout=30)
        zstd_work.unlink()
    else:
        for path in paths:
            with tarfile.open(path, "r:gz") as archive:
                extract(archive)
    assert seen == set(expected)
    return {"artifact_index_sha256": sha(folder / "artifact-index.json"), "parts_verified": len(paths), "all_archived_members_hashed": len(seen), "members_materialized_for_replay": len(selected)}


def extract_runtime(archive_path, destination):
    count = 0
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive:
            relative = safe_relative(member.name)
            assert member.isdir() or member.isfile()
            path = destination / relative
            if member.isdir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as target, archive.extractfile(member) as source:
                    shutil.copyfileobj(source, target)
                count += 1
    assert (destination / "scripts/benchmark_context_solver.py").is_file()
    return count


def worker(args):
    output = args.output.resolve()
    data = output / "inputs"
    runtime = data / "frozen-runtime"
    roots = [output, Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve(), Path("/usr/lib"), Path("/usr/local/lib"), Path("/usr/share")]
    exact = {Path(p) for p in ["/dev/null", "/dev/urandom", "/etc/localtime", "/etc/os-release", "/etc/ssl/openssl.cnf", "/etc/nsswitch.conf", "/etc/hosts", "/etc/resolv.conf"]}
    denied = collections.Counter()
    denial_details = []
    probes = True

    def audit(event, values):
        if event in {"subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "socket.connect", "socket.connect_ex", "socket.getaddrinfo"}:
            denied["probe" if probes else "external_process_or_network"] += 1
            if not probes:
                executable = values[0]
                denial_details.append({"event": event, "executable_basename": Path(os.fsdecode(executable)).name if isinstance(executable, (str, bytes)) else None, "operation": "blocked_before_execution"})
            raise PermissionError("Relocated receipt replay forbids processes and networking")
        if event != "open" or isinstance(values[0], int):
            return
        path = Path(os.fsdecode(values[0])).resolve()
        mode, flags = values[1:3]
        writing = any(x in (mode or "") for x in "wa+") or flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
        allowed = path == Path("/dev/null") or (path.is_relative_to(output) if writing else path in exact or any(path.is_relative_to(root) for root in roots))
        if not allowed:
            denied["probe" if probes else "outside_relocated_data_or_dependencies"] += 1
            if not probes:
                frame = sys._getframe(1)
                denial_details.append({"event": event, "basename": path.name, "operation": "blocked_before_open", "caller_module_file": Path(frame.f_code.co_filename).name, "caller_function": frame.f_code.co_name})
            raise PermissionError("File access outside declared replay/dependency roots")

    sys.addaudithook(audit)
    for operation in [lambda: open("/forbidden-original-evidence/probe.json"), lambda: subprocess.run(["/bin/true"])]:
        try:
            operation()
        except PermissionError:
            pass
        else:
            raise AssertionError("Replay isolation probe did not reject access")
    assert denied["probe"] == 2
    probes = False
    # Editable-install metadata can inject the original checkout into sys.path.
    # Keep only the declared runtime and installed dependency roots.
    sys.path[:] = [str(runtime)] + [entry for entry in sys.path if entry and any(Path(entry).resolve().is_relative_to(root) for root in roots)]
    from scripts.benchmark_context_solver import model_observations
    from scripts.contextbench_selected_context import selected_context
    from scripts.contextbench_search_pair_solver import _session, whole_run_usage

    origins = {}
    for name, module in list(sys.modules.items()):
        if name in {"scripts", "codenib"} or name.startswith(("scripts.", "codenib.")):
            filename = getattr(module, "__file__", None)
            assert filename and Path(filename).resolve().is_relative_to(runtime)
            origins[name] = {"file": Path(filename).resolve().relative_to(runtime).as_posix(), "sha256": sha(Path(filename))}
    manifest_paths = sorted((data / "repair/publication-support").rglob("redaction-manifest.json"))
    assert manifest_paths
    manifests = [load(path) for path in manifest_paths]
    original = {}
    for manifest in manifests:
        for item in manifest["members"]:
            name = item["name"]
            assert name not in original or original[name]["original_sha256"] == item["original_sha256"]
            original[name] = item
    links = {}
    for path in sorted((data / "repair/publication-support").rglob("session-digest-linkage.json")):
        for new, old in load(path).items():
            assert new not in links or links[new] == old
            links[new] = old
    search_links = load(data / "search-session-digest-linkage.json")
    rows = [json.loads(line) for line in (data / "repair" / safe_relative(args.closed_index)).read_text().splitlines()]
    assert len(rows) == len({row["instance_id"] for row in rows}) == args.cases
    assert set().union(*(set(m["canonical_case_ids"]) for m in manifests)) == {row["instance_id"] for row in rows}
    assert sum(len(m["canonical_case_ids"]) for m in manifests) == args.cases
    records, sessions, repair_calls, search_calls = [], set(), 0, 0
    repair_cost, search_cost = Decimal(0), Decimal(0)
    for number, row in enumerate(rows, 1):
        identity = row["instance_id"]
        solver_dir = data / "repair" / safe_relative(row["solver_run"])
        native_dir = data / "repair" / safe_relative(row["native_run"])
        solver = load(solver_dir / "solver.json")
        observations = model_observations(solver)
        assert observations == load(solver_dir / "model-observations.json") and observations["all_model_inputs_confirmed"]
        search = load(data / "search/logs/cases" / identity / "haiku_scout_pair-prediction.json")
        selected, _ = selected_context(search, observations, solver["model_patch"])
        assert selected == load(data / "repair" / safe_relative(row["selected_context"]))
        handoff = load(solver_dir / "search-pair-handoff.json")
        actual_search = []
        for label in ["first", "scout"]:
            raw = load(data / "search/trajectories" / identity / label / "trajectory.json")
            assert raw["sdk_reported_cost_usd"] == raw["sdk_result"]["total_cost_usd"]
            session = _session("search:" + label, raw["sdk_result"], raw["sdk_reported_cost_usd"], raw.get("billing_route"))
            session["session_id_sha256"] = search_links[session["session_id_sha256"]]
            actual_search.append(session)
            search_calls += 1
        assert actual_search == handoff["search_sessions"]
        usage = whole_run_usage(handoff, solver, True)
        for session in usage["sessions"]:
            if session["phase"].startswith("repair:"):
                session["session_id_sha256"] = links[session["session_id_sha256"]]
                repair_cost += Decimal(str(session["usage_usd"]))
            else:
                search_cost += Decimal(str(session["usage_usd"]))
            assert session["session_id_sha256"] not in sessions
            sessions.add(session["session_id_sha256"])
        assert usage == load(solver_dir / "whole-run-usage.json")
        native_config, native = load(native_dir / "config.json"), load(native_dir / "resolution.json")
        assert native_config["solver_sha256"] == original[row["solver_run"] + "/solver.json"]["original_sha256"]
        assert native_config["prediction_sha256"] == row["first_patch_sha256"] == sha(solver_dir / "predictions.json")
        predictions = load(solver_dir / "predictions.json")
        assert len(predictions) == 1 and predictions[0]["model_patch"] == solver["model_patch"]
        assert native["status"] == "graded" and native["resolved"] == row["resolved"]
        assert original[row["native_run"] + "/whole-run-result.json"]["original_sha256"] == row["whole_run_result_sha256"]
        whole = load(native_dir / "whole-run-result.json")
        assert whole["usage"] == usage and whole["native_resolution"] == row["resolved"]
        repair_calls += len(solver["calls"])
        records.append({"instance_id": identity, "resolved": row["resolved"], "confirmed_repair_inputs": len(observations["confirmed_inputs"]), "search_sessions_from_actual_public_raw": 2, "selected_context_recompiled_identically": True, "usage_recompiled_identically": True, "native_result_bound_to_original_first_patch": True, "retrospective_selection_disclosed": row["retrospective_final_selection_disclosed"]})
        if number % 20 == 0:
            print(json.dumps({"relocated_cases_replayed": number, "model_calls": 0}), flush=True)
    assert len(records) == args.cases and search_calls == 2 * args.cases
    save(output / "guard-diagnostics.json", {"counts": dict(denied), "denied_operations": denial_details})
    # Optional user-config/processor probes may be caught by dependencies.
    # They remain blocked; record them rather than granting external access.
    nonprobe_denials = sum(count for label, count in denied.items() if label != "probe")
    assert nonprobe_denials == len(denial_details)
    save(output / "relocated-cases.json", records)
    save(output / "frozen-module-origins.json", origins)
    save(output / "worker-verification.json", {"cases": len(records), "resolved": sum(row["resolved"] for row in records), "unresolved": sum(not row["resolved"] for row in records), "repair_SDK_calls_replayed": repair_calls, "search_SDK_fees_replayed_from_actual_raw": search_calls, "unique_search_and_repair_sessions": len(sessions), "repair_usage_decimal": str(repair_cost), "search_usage_decimal": str(search_cost), "total_modeled_usage_decimal": str(repair_cost + search_cost), "all_original_first_patch_native_bindings_reauthenticated": True, "all_selected_contexts_and_usage_recomputed_identically": True, "all_CodeNib_modules_loaded_from_bundled_frozen_runtime": True, "original_checkout_and_original_experiment_files_not_opened": True, "Python_open_guard_scope_not_OS_sandbox": True, "network_and_external_processes_forbidden": True, "isolation_probe_rejections": denied["probe"], "nonprobe_denials": nonprobe_denials, "blocked_dependency_probes": denial_details, "fresh_clone_source_footprints_replayed": False, "native_tests_rerun": 0, "new_model_calls": 0, "financial_mutations": 0, "formal_full500_submission_ready": False})


def parent(args):
    args.output.mkdir(exist_ok=False)
    output = args.output.resolve()
    data = output / "inputs"
    data.mkdir()
    save(output / "intent.json", {"pid": os.getpid(), "driver_sha256": sha(Path(__file__)), "expected_cases": args.cases, "closed_index": args.closed_index, "inputs_are_public_parts_only": True, "originals_read_only": True, "new_model_calls": 0})
    repair_proofs = []
    for number, parts in enumerate(args.repair_parts):
        repair_proofs.append(decode_parts(parts, data / "repair", lambda name: needed_repair(name, args.closed_index), zstd_work=output / f"repair-{number}.tar.zst"))
        print(json.dumps({"repair_part_sets_decoded": number + 1, "all_members_hashed": repair_proofs[-1]["all_archived_members_hashed"]}), flush=True)
    runtime_archive = data / "repair/publication-support/repair-runtime-source.tar.gz"
    runtime_members = extract_runtime(runtime_archive, data / "frozen-runtime")
    search_proof = decode_parts(args.search_parts, data / "search", lambda name: name.endswith(("/haiku_scout_pair-prediction.json", "/trajectory.json")), zstd_work=output / "unused-search-stream")
    shutil.copyfile(args.search_linkage, data / "search-session-digest-linkage.json")
    save(output / "extraction-verification.json", {"repair_split_part_sets": repair_proofs, "search_split_part_set": search_proof, "runtime_archive_sha256": sha(runtime_archive), "runtime_files_extracted": runtime_members, "search_public_digest_linkage_sha256": sha(data / "search-session-digest-linkage.json")})
    driver = output / "replay-driver.py"
    shutil.copyfile(Path(__file__), driver)
    (output / "tmp").mkdir()
    env = {"PATH": "/usr/bin:/bin", "LC_ALL": "C.UTF-8", "LITELLM_LOCAL_MODEL_COST_MAP": "True", "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_HOME": str(output / "cache/hf"), "XDG_CACHE_HOME": str(output / "cache"), "TIKTOKEN_CACHE_DIR": str(output / "cache/tokenizers"), "TMPDIR": str(output / "tmp")}
    with (output / "worker.log").open("x") as log:
        completed = subprocess.run([sys.executable, "-I", "-B", str(driver), "--worker", "--output", str(output), "--cases", str(args.cases), "--closed-index", args.closed_index], cwd=output, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    assert completed.returncode == 0, "Relocated replay failed; original records are unchanged"
    proof = load(output / "worker-verification.json")
    proof.update({"repair_split_part_sets": repair_proofs, "search_split_part_set": search_proof, "bundled_runtime_files_extracted": runtime_members, "runtime_archive_sha256": sha(runtime_archive), "search_public_digest_linkage_sha256": sha(data / "search-session-digest-linkage.json"), "driver_sha256": sha(driver), "selective_extraction_only_full_archives_preserved": True, "official_context_scoring_rerun": False, "publication_approved": False})
    save(output / "verification.json", proof)
    print(json.dumps(proof), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repair-parts", action="append", type=Path)
    parser.add_argument("--search-parts", type=Path)
    parser.add_argument("--search-linkage", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cases", type=int, required=True)
    parser.add_argument("--closed-index", required=True)
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    worker(args) if args.worker else parent(args)
