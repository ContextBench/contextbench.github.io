Private completed231 relocated receipt replay

These artifacts remain private; they are not a formal full500 submission.

Use replay_publication_repair_receipts.py unchanged, SHA256:
23b548d5853aab523237914eac3de7f4c31377f2f565086f478c70fc8fbe95b6

Preserve the four separate repair part folders (completed58, completed64,
completed55 and completed-Pro54), the search publication-copy packaged folder,
and its search-session-digest-linkage.json. Each retains its own artifact-index.
A portable command after arranging those inputs under CB_BUNDLE is:

CB_BUNDLE=/path/to/bench-bundle
python "$CB_BUNDLE/replay_publication_repair_receipts.py" \
  --repair-parts "$CB_BUNDLE/completed58-publication-preview/parts" \
  --repair-parts "$CB_BUNDLE/completed64-publication-preview/parts" \
  --repair-parts "$CB_BUNDLE/completed55-publication-preview/parts" \
  --repair-parts "$CB_BUNDLE/completed-Pro54-publication-preview/parts" \
  --search-parts "$CB_BUNDLE/search-publication-copy/packaged" \
  --search-linkage "$CB_BUNDLE/search-session-digest-linkage.json" \
  --cases 231 \
  --closed-index canonical500-candidate-repair/completed231-raw-index/repair-index.jsonl \
  --output /path/to/fresh-replay-directory

The closed-index member is repair-index.jsonl, not index.json. Output must be
fresh; do not overwrite any existing run. Decoder extraction is selective,
but every actual part/member is authenticated and complete originals stay intact.

Actual replay validates 42 split parts (32 repair plus10 search), 43,510 member
occurrences and1,703 bundled runtime files. All231 original selections and first
patch/native bindings reproduce, retaining188 resolved and43 unresolved cases.
It replays2,059 repair inputs and462 original search SDK fee receipts:
2,521 unique sessions and$141.76314628 total allocated usage.

The worker loads CodeNib from the bundled runtime and installed dependencies.
Python audit guards deny original checkout/experiment reads, networking and child
processes; both isolation probes reject access, and three optional dependency
probes remain blocked. This is not an OS sandbox, a clean dependency install,
fresh-clone source-footprint replay, native-test reproduction or official rescoring.
There are no model calls, new API charges or financial mutations.

Pro's separate actual-part review retains216 findings, each classified against
complete byte-identical public upstream source blobs (53 unique blobs, three
repositories, anonymously fetched at pinned commits). Together with128 earlier
Sphinx public-fixture findings, composition retains and binds all344 findings.
These declared-pattern checks do not prove arbitrary PII/secrets absent.
Full500 outcomes, final context scoring, publication and comparability remain open.

Actual verification follows:
{
  "cases": 231,
  "resolved": 188,
  "unresolved": 43,
  "repair_SDK_calls_replayed": 2059,
  "search_SDK_fees_replayed_from_actual_raw": 462,
  "unique_search_and_repair_sessions": 2521,
  "repair_usage_decimal": "139.390428200000000767",
  "search_usage_decimal": "2.3727180800000000118",
  "total_modeled_usage_decimal": "141.7631462800000007788",
  "all_original_first_patch_native_bindings_reauthenticated": true,
  "all_selected_contexts_and_usage_recomputed_identically": true,
  "all_CodeNib_modules_loaded_from_bundled_frozen_runtime": true,
  "original_checkout_and_original_experiment_files_not_opened": true,
  "Python_open_guard_scope_not_OS_sandbox": true,
  "network_and_external_processes_forbidden": true,
  "isolation_probe_rejections": 2,
  "nonprobe_denials": 3,
  "blocked_dependency_probes": [
    {
      "event": "subprocess.Popen",
      "executable_basename": "git",
      "operation": "blocked_before_execution"
    },
    {
      "event": "subprocess.Popen",
      "executable_basename": "fc-list",
      "operation": "blocked_before_execution"
    },
    {
      "event": "open",
      "basename": ".igraphrc",
      "operation": "blocked_before_open",
      "caller_module_file": "configuration.py",
      "caller_function": "load"
    }
  ],
  "fresh_clone_source_footprints_replayed": false,
  "native_tests_rerun": 0,
  "new_model_calls": 0,
  "financial_mutations": 0,
  "formal_full500_submission_ready": false,
  "repair_split_part_sets": [
    {
      "artifact_index_sha256": "b33f5951517ef7a2b2c39c9fee628fc97ebf847fb48733d210e6bde01ac9839d",
      "parts_verified": 3,
      "all_archived_members_hashed": 7703,
      "members_materialized_for_replay": 1073
    },
    {
      "artifact_index_sha256": "a55d9eaa4a74fc2d50d10f08756f9475357f5254f7f8d8fe79df707bdc131620",
      "parts_verified": 15,
      "all_archived_members_hashed": 9070,
      "members_materialized_for_replay": 1378
    },
    {
      "artifact_index_sha256": "045e299abaa23139ea6318535e0132bf2335c95ff9e2df0be807584df83a33b2",
      "parts_verified": 9,
      "all_archived_members_hashed": 8193,
      "members_materialized_for_replay": 1151
    },
    {
      "artifact_index_sha256": "65323498480b825e0bda1f74f3ebea1969438376fa212bd083404059d2a1afb4",
      "parts_verified": 5,
      "all_archived_members_hashed": 9899,
      "members_materialized_for_replay": 1185
    }
  ],
  "search_split_part_set": {
    "artifact_index_sha256": "f65c5eb639225bd1e5da52a0fd734c17517cef7364d028e5e11d1a1d65695864",
    "parts_verified": 10,
    "all_archived_members_hashed": 8645,
    "members_materialized_for_replay": 1500
  },
  "bundled_runtime_files_extracted": 1703,
  "runtime_archive_sha256": "167f6c9546ad0536e9e2ba9ad2b043843f1baef5eb70ef83728fc7e351d7f41a",
  "search_public_digest_linkage_sha256": "865e7400e733aa121b1265e1c262c3648e34197a643203d6f21d22379ae1a29d",
  "driver_sha256": "23b548d5853aab523237914eac3de7f4c31377f2f565086f478c70fc8fbe95b6",
  "selective_extraction_only_full_archives_preserved": true,
  "official_context_scoring_rerun": false,
  "publication_approved": false
}
